package uz.sinov.service.testing;


import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.GroupTeacher;
import uz.sinov.entity.testing.StudentTask;
import uz.sinov.entity.testing.Task;
import uz.sinov.entity.testing.TestCriteria;
import uz.sinov.enums.StudentTaskStatus;
import uz.sinov.payload.request.task.TaskCreateRequestDto;
import uz.sinov.payload.request.task.TaskStartRequestDto;
import uz.sinov.payload.request.test_session.TestSessionIdRequestDto;
import uz.sinov.payload.response.task.TaskResponseDto;
import uz.sinov.payload.response.test_session.TestCriteriaResponseDto;
import uz.sinov.payload.response.test_session.TestSessionStartResponseDto;
import uz.sinov.repository.GroupTeacherRepository;
import uz.sinov.repository.StudentTaskRepository;
import uz.sinov.repository.TaskRepository;
import uz.sinov.service.GroupService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class TaskService {
    private final TaskRepository taskRepository;
    private final GroupService groupService;
    private final SessionUser sessionUser;
    private final GroupTeacherRepository groupTeacherRepository;
    private final StudentTaskService studentTaskService;
    private final StudentTaskRepository studentTaskRepository;
    private final TestSessionService testSessionService;
    private final TestCriteriaService testCriteriaService;

    public TaskService(TaskRepository taskRepository, GroupService groupService, SessionUser sessionUser,
                       GroupTeacherRepository groupTeacherRepository, StudentTaskService studentTaskService,
                       StudentTaskRepository studentTaskRepository, @Lazy TestSessionService testSessionService, TestCriteriaService testCriteriaService) {
        this.taskRepository = taskRepository;
        this.groupService = groupService;
        this.sessionUser = sessionUser;
        this.groupTeacherRepository = groupTeacherRepository;
        this.studentTaskService = studentTaskService;
        this.studentTaskRepository = studentTaskRepository;
        this.testSessionService = testSessionService;
        this.testCriteriaService = testCriteriaService;
    }

    public String create(TaskCreateRequestDto request) {
        String userId = sessionUser.id();
        String groupId = request.getGroupId();
        groupService.findById(groupId);

        Optional<GroupTeacher> groupTeacherOptional = groupTeacherRepository.findByGroupIdAndUserId(groupId, userId);
        if (groupTeacherOptional.isEmpty()) {
            throw new RuntimeException("You are not allowed add task to this group");
        }

        if (request.getDeadline().isBefore(LocalDateTime.now().plusDays(1))) {
            throw new RuntimeException("Deadline must be at least 1 day later");
        }
        TestCriteria testCriteria = testCriteriaService.mapToTestCriteria(request.getCriteria());
        Task task = Task.childBuilder()
                .groupId(groupId)
                .deadline(request.getDeadline())
                .criteria(testCriteria)
                .name(request.getName())
                .description(request.getDescription())
                .build();
        taskRepository.save(task);

        studentTaskService.create(task);

        return "Task created successfully";
    }

    public TestSessionStartResponseDto start(TaskStartRequestDto request) {
        String userId = sessionUser.id();
        String taskId = request.getTaskId();
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        StudentTask studentTask = studentTaskRepository.findByStudentIdAndTaskId(userId, taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        if (Objects.equals(studentTask.getStatus(), StudentTaskStatus.FINISHED)) {
            throw new RuntimeException("You have already finished this task");
        }

        studentTask.setStatus(StudentTaskStatus.STARTED);
        studentTaskRepository.save(studentTask);

        TestSessionIdRequestDto testSessionIdRequestDto = new TestSessionIdRequestDto(studentTask.getTestSessionId());
        return testSessionService.startTestSession(testSessionIdRequestDto);
    }

    public void finish(TestSessionIdRequestDto request) {
        String userId = sessionUser.id();
        String testSessionId = request.getTestSessionId();

        Optional<StudentTask> studentTaskOptional = studentTaskRepository.findByStudentIdAndTestSessionId(userId, testSessionId);
        if (studentTaskOptional.isPresent()) {
            StudentTask studentTask = studentTaskOptional.get();
            studentTask.setStatus(StudentTaskStatus.FINISHED);
            studentTaskRepository.save(studentTask);
        }
    }

    public List<TaskResponseDto> getGroupTasks(String groupId) {
        groupService.findById(groupId);
        List<Task> tasks = taskRepository.findByGroupId(groupId);
        return this.mapToResponse(tasks);
    }

    public List<TaskResponseDto> mapToResponse(List<Task> tasks) {
        return tasks.stream()
                .map(this::mapToResponse)
                .toList();
    }

    public TaskResponseDto mapToResponse(Task task) {
        TestCriteriaResponseDto responseTestCriteria = new TestCriteriaResponseDto();
        if (Objects.nonNull(task.getCriteria())) {
            responseTestCriteria = testCriteriaService.mapToResponseTestCriteria(task.getCriteria());
        }
        return TaskResponseDto.builder()
                .id(task.getId())
                .groupId(task.getGroupId())
                .name(task.getName())
                .description(task.getDescription())
                .deadline(task.getDeadline())
                .criteria(responseTestCriteria)
                .build();
    }
}
