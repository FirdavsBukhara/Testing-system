package uz.sinov.service;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Organization;
import uz.sinov.entity.UserSubscription;
import uz.sinov.enums.TarifType;
import uz.sinov.enums.UserStatus;
import uz.sinov.enums.UserSubscriptionStatus;
import uz.sinov.mappers.OrganizationMapper;
import uz.sinov.payload.request.PagingRequest;
import uz.sinov.payload.request.organization.OrganizationCreateRequestDto;
import uz.sinov.payload.response.PageableResponseDto;
import uz.sinov.payload.response.PagingResponse;
import uz.sinov.payload.response.auth.UserResponseDto;
import uz.sinov.payload.response.organization.AddressResponseDto;
import uz.sinov.payload.response.organization.OrganizationResponseDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;
import uz.sinov.repository.OrganizationRepository;
import uz.sinov.repository.UserSubscriptionRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class OrganizationService {
    private final OrganizationRepository organizationRepository;
    private final SessionUser sessionUser;
    private final AuthUserService authUserService;
    private final UserSubscriptionRepository userSubscriptionRepository;
    private final TarifService tarifService;
    private final AddressService addressService;
    private final OrganizationMapper organizationMapper;

    public String createOrganization(OrganizationCreateRequestDto dto) {
        final String userId = sessionUser.id();
        AuthUser user = authUserService.findById(userId);
        if (!Objects.equals(user.getStatus(), UserStatus.ACTIVE)) {
            throw new RuntimeException("User is not active");
        }

        UserSubscription userSubscription = userSubscriptionRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User has no subscription"));

        if (!Objects.equals(userSubscription.getStatus(), UserSubscriptionStatus.ACTIVE)) {
            throw new RuntimeException("Subscription is not active");
        }

        TarifResponseDto tarifResponseById = tarifService.findTarifResponseById(userSubscription.getTarifId());
        if (!Objects.equals(tarifResponseById.getType(), TarifType.ORGANIZATIONAL)) {
            throw new RuntimeException("You have no permission to create organization");
        }
        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionRepository.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }

        TarifConstraintResponseDto tarifConstraintResponseDto = tarifResponseById.getConstraint();
        short maxOrganizationCount = tarifConstraintResponseDto.getMaxOrganizationCount();
        long organizationCount = organizationRepository.countByDirectorId(userId);
        if (organizationCount >= maxOrganizationCount) {
            throw new RuntimeException("You have reached the maximum number of organizations");
        }

        addressService.findById(dto.getAddressId());

        Organization organization = Organization.childBuilder()
                .directorId(userId)
                .name(dto.getName())
                .addressId(dto.getAddressId())
                .description(dto.getDescription())
                .build();
        organizationRepository.save(organization);
        return "Organization added successfully";
    }

    public List<OrganizationResponseDto> getMyOrganizations() {
        final String userId = sessionUser.id();
        List<Organization> organizations = organizationRepository.findByDirectorId(userId);
        return this.mapToOrganizationResponseDtoList(organizations);
    }

    public OrganizationResponseDto organizationResponseById(String id) {
        final String userId = sessionUser.id();
        Organization organization = organizationRepository.findByIdAndDirectorId(id, userId)
                .orElseThrow(() -> new RuntimeException("Organization not found"));
        AddressResponseDto addressResponseDto = addressService.findResponseById(organization.getAddressId());
        UserResponseDto responseDirectorById = authUserService.findUserResponseById(organization.getDirectorId());
        return organizationMapper.mapToOrganizationResponseDto(organization, addressResponseDto, responseDirectorById);
    }

    private List<OrganizationResponseDto> mapToOrganizationResponseDtoList(List<Organization> organizations) {
        return organizations.stream()
                .map(organization -> {
                    UserResponseDto responseDirectorById = authUserService.findUserResponseById(organization.getDirectorId());
                    AddressResponseDto addressResponseDto = addressService.findResponseById(organization.getAddressId());
                    return organizationMapper.mapToOrganizationResponseDto(organization, addressResponseDto, responseDirectorById);
                })
                .toList();
    }

    public Organization findById(String organizationId) {
        return organizationRepository.findById(organizationId)
                .orElseThrow(() -> new EntityNotFoundException("Organization not found"));
    }

    public PageableResponseDto<OrganizationResponseDto> getAllOrganizations(PagingRequest paging) {
        PageRequest pageRequest = PageRequest.of(paging.getPage(), paging.getSize());
        Page<Organization> organizationPage = organizationRepository.findAll(pageRequest);

        List<OrganizationResponseDto> organizationResponseDtoList = this.mapToOrganizationResponseDtoList(organizationPage.getContent());

        PagingResponse pagingResponse = PagingResponse.of(paging, organizationPage.getTotalElements());
        return new PageableResponseDto<>(organizationResponseDtoList, pagingResponse);
    }
}
