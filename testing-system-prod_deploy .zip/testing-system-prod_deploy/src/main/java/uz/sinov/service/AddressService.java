package uz.sinov.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.Address;
import uz.sinov.mappers.AddressMapper;
import uz.sinov.payload.request.organization.AddressCreateRequestDto;
import uz.sinov.payload.response.organization.AddressResponseDto;
import uz.sinov.repository.AddressRepository;

@Service
@RequiredArgsConstructor
public class AddressService {
    private final AddressRepository addressRepository;
    private final AddressMapper addressMapper;

    public AddressResponseDto create(AddressCreateRequestDto dto) {
        return null;
    }

    public Address findById(Integer id) {
        return addressRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Address not found"));
    }

    public AddressResponseDto findResponseById(Integer id) {
        Address address = this.findById(id);
        return addressMapper.mapToResponseAddress(address);
    }
}
