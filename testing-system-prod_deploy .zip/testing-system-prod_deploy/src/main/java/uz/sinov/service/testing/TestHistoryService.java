package uz.sinov.service.testing;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Document;
import uz.sinov.entity.testing.Answer;
import uz.sinov.entity.testing.Question;
import uz.sinov.entity.testing.QuestionLevel;
import uz.sinov.entity.testing.SolveQuestion;
import uz.sinov.entity.testing.TestCriteria;
import uz.sinov.entity.testing.TestHistory;
import uz.sinov.entity.testing.TestSession;
import uz.sinov.payload.request.PagingRequest;
import uz.sinov.payload.request.pdf.PdfOneQuestionDto;
import uz.sinov.payload.request.pdf.PdfParagraphDto;
import uz.sinov.payload.request.pdf.PdfSubjectDto;
import uz.sinov.payload.response.PageableResponseDto;
import uz.sinov.payload.response.PagingResponse;
import uz.sinov.payload.response.test_history.TestHistoryResponseDto;
import uz.sinov.payload.response.test_session.TestCountsResponseDto;
import uz.sinov.repository.TestHistoryRepository;
import uz.sinov.repository.TestSessionRepository;
import uz.sinov.service.AuthUserService;
import uz.sinov.service.DocumentService;
import uz.sinov.service.pdf.PdfService;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class TestHistoryService {
    private final TestHistoryRepository testHistoryRepository;
    private final SolveQuestionService solveQuestionService;
    private final QuestionService questionService;
    private final AnswerService answerService;
    private final PdfService pdfService;
    private final AuthUserService authUserService;
    private final TestSessionRepository testSessionRepository;
    private final DocumentService documentService;
    private final SessionUser sessionUser;

    public void generateHistory(TestSession testSession, TestCountsResponseDto testCountsResponseDto) {
        try {
            String userId = testSession.getUserId();

            String testSessionId = testSession.getId();
            Optional<TestHistory> optionalTestHistory = testHistoryRepository.findByTestSessionId(testSessionId);
            if (optionalTestHistory.isPresent()) {
                TestHistory testHistory = optionalTestHistory.get();
                log.warn("Test history already generated for test session id: {}", testSessionId);
                if (Objects.isNull(testHistory.getDocumentId())) {
                    this.generateAndSavePdf(testHistory.getId());
                }
                return;
            }

            List<SolveQuestion> solveQuestionList = solveQuestionService.findAllByTestSessionId(testSessionId);

            float totalScore = 0.0f;

            for (SolveQuestion solveQuestion : solveQuestionList) {
                Question question = questionService.findById(solveQuestion.getQuestionId());
                Answer answer = answerService.findCorrectByQuestionId(solveQuestion.getQuestionId());
                if (Objects.nonNull(answer) && answer.getId().equals(solveQuestion.getUserAnswerId())) {
                    QuestionLevel questionLevel = question.getQuestionLevel();
                    totalScore += questionLevel.getScore();
                }
            }

            TestHistory testHistory = TestHistory.builder()
                    .userId(userId)
                    .testSessionId(testSessionId)
                    .startedAt(testSession.getStartedAt())
                    .finishedAt(testSession.getFinishedAt())
                    .totalScore(totalScore)
                    .totalQuestionCount(testCountsResponseDto.getTotalQuestionCount())
                    .correctAnswerCount(testCountsResponseDto.getCorrectAnswerCount())
                    .wrongAnswerCount(testCountsResponseDto.getWrongAnswerCount())
                    .emptyAnswerCount(testCountsResponseDto.getEmptyAnswerCount())
                    .build();

            testHistoryRepository.save(testHistory);
            log.info("Test history generated successfully for test session id: {}", testSessionId);

            this.generateAndSavePdf(testHistory.getId());

        } catch (Exception exception) {
            log.error("Error while generating pdf", exception);
        }
    }

    private void generateAndSavePdf(Integer testHistoryId) throws IOException {
        TestHistory testHistory = testHistoryRepository.findById(testHistoryId)
                .orElseThrow(() -> new RuntimeException("Test history not found with id '%s'".formatted(testHistoryId)));

        String userId = testHistory.getUserId();
        String testSessionId = testHistory.getTestSessionId();

        AuthUser user = authUserService.findById(userId);
        TestSession testSession = testSessionRepository.findByUserIdAndId(userId, testSessionId)
                .orElseThrow(() -> new RuntimeException("Test session not found with id '%s'".formatted(testSessionId)));

        List<SolveQuestion> solveQuestionList = solveQuestionService.findAllByTestSessionId(testSessionId);


        float totalScore = 0.0f;

        for (SolveQuestion solveQuestion : solveQuestionList) {
            Question question = questionService.findById(solveQuestion.getQuestionId());
            Answer answer = answerService.findCorrectByQuestionId(solveQuestion.getQuestionId());

            if (Objects.nonNull(answer) && answer.getId().equals(solveQuestion.getUserAnswerId())) {
                QuestionLevel questionLevel = question.getQuestionLevel();
                totalScore += questionLevel.getScore();
            }
        }
        PdfParagraphDto pdfParagraphDto = new PdfParagraphDto();
        pdfParagraphDto.setPhoneNumber(user.getPhoneNumber());
        pdfParagraphDto.setFullName(user.getName());
        pdfParagraphDto.setStartedAt(testHistory.getStartedAt());
        pdfParagraphDto.setFinishedAt(testHistory.getFinishedAt());
        pdfParagraphDto.setTotalScore(totalScore);

        List<PdfSubjectDto> pdfSubjectDtoList = new ArrayList<>();
        List<TestCriteria> criteria = testSession.getCriteria();
        for (TestCriteria testCriteria : criteria) {
            PdfSubjectDto pdfSubjectDto = new PdfSubjectDto();
            pdfSubjectDto.setSubjectName(testCriteria.getSubject().getName());
            List<PdfOneQuestionDto> pdfOneQuestionDtoList = solveQuestionList.stream()
                    .filter(sq -> sq.getSubjectId().equals(testCriteria.getSubject().getId()))
                    .map(sq -> {
                        Question question = questionService.findById(sq.getQuestionId());
                        Answer answer = answerService.findCorrectByQuestionId(sq.getQuestionId());
                        PdfOneQuestionDto oneQuestionDto = new PdfOneQuestionDto();
                        if (Objects.nonNull(answer) && answer.getId().equals(sq.getUserAnswerId())) {
                            oneQuestionDto.setCorrect(true);
                            oneQuestionDto.setScore(question.getQuestionLevel().getScore());
                        } else {
                            oneQuestionDto.setCorrect(false);
                            oneQuestionDto.setScore(0.0f);
                        }
                        return oneQuestionDto;
                    })
                    .toList();
            pdfSubjectDto.setQuestionList(pdfOneQuestionDtoList);
            pdfSubjectDtoList.add(pdfSubjectDto);
        }

        File file = pdfService.generatePDF(pdfParagraphDto, pdfSubjectDtoList);

        Document document = documentService.savePdfFile(file);
        testHistory.setDocumentId(document.getGeneratedName());
        testHistoryRepository.save(testHistory);
    }

    public PageableResponseDto<TestHistoryResponseDto> getMyHistory(PagingRequest paging) {
        String userId = sessionUser.id();
        return this.getUserTestHistoryList(userId, paging);
    }

    public PageableResponseDto<TestHistoryResponseDto> getUserTestHistoryList(String userId, PagingRequest paging) {
        Sort sort = Sort.by(Sort.Direction.DESC, "startedAt");
        Pageable pageable = PageRequest.of(paging.getPage(), paging.getSize(), sort);
        Page<TestHistory> page = testHistoryRepository.findByUserId(userId, pageable);
        List<TestHistoryResponseDto> testHistoryResponseDtoList = this.mapToResponse(page.getContent());

        PagingResponse pagingResponse = PagingResponse.of(paging, page.getTotalElements());

        return new PageableResponseDto<>(testHistoryResponseDtoList, pagingResponse);
    }

    private List<TestHistoryResponseDto> mapToResponse(List<TestHistory> content) {
        return content.stream()
                .map(this::mapToResponse)
                .toList();
    }

    private TestHistoryResponseDto mapToResponse(TestHistory testHistory) {
        return TestHistoryResponseDto.builder()
                .id(testHistory.getId())
                .startedAt(testHistory.getStartedAt())
                .finishedAt(testHistory.getFinishedAt())
                .totalScore(testHistory.getTotalScore())
                .testSessionId(testHistory.getTestSessionId())
                .userId(testHistory.getUserId())
                .documentId(testHistory.getDocumentId())
                .totalQuestionCount(testHistory.getTotalQuestionCount())
                .correctAnswerCount(testHistory.getCorrectAnswerCount())
                .wrongAnswerCount(testHistory.getWrongAnswerCount())
                .emptyAnswerCount(testHistory.getEmptyAnswerCount())
                .build();
    }
}
