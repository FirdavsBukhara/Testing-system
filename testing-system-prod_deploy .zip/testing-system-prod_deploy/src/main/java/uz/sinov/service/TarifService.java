package uz.sinov.service;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.Tarif;
import uz.sinov.entity.TarifConstraint;
import uz.sinov.enums.TarifStatus;
import uz.sinov.enums.TarifType;
import uz.sinov.mappers.TarifConstraintMapper;
import uz.sinov.mappers.TarifMapper;
import uz.sinov.payload.request.tarif.TarifCreateRequestDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;
import uz.sinov.repository.TarifRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class TarifService {
    private final TarifConstraintService tarifConstraintService;

    private final TarifRepository tarifRepository;

    private final TarifMapper tarifMapper;
    private final TarifConstraintMapper tarifConstraintMapper;

    public String createTarif(TarifCreateRequestDto dto) {
        if (dto.getFromTime().isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("From time should be after current time");
        }
        if (dto.getToTime().isBefore(dto.getFromTime())) {
            throw new IllegalArgumentException("To time should be after from time");
        }
        Tarif tarif = tarifMapper.mapToTarif(dto);
        tarif.setStatus(TarifStatus.ACTIVE);
        tarifRepository.save(tarif);

        tarifConstraintService.create(tarif, dto.getConstraint());

        return "Tarif created successfully";
    }

    public List<TarifResponseDto> getTarifs(String type) {
        List<Tarif> list;
        if (type.equalsIgnoreCase("all")) {
            list = tarifRepository.findAll();
        } else {
            TarifType tarifType = TarifType.getByName(type);
            list = tarifRepository.findByType(tarifType);
        }
        return this.convertToResponseDtoList(list);
    }

    private List<TarifResponseDto> convertToResponseDtoList(List<Tarif> list) {
        return list.stream()
                .map(tarif -> {
                    TarifConstraint tarifConstraint = tarifConstraintService.findByTarifIdOrElseNull(tarif.getId());
                    TarifConstraintResponseDto tarifConstraintResponseDto = null;
                    if (!Objects.isNull(tarifConstraint)) {
                        tarifConstraintResponseDto = tarifConstraintMapper.mapToConstraintResponseDto(tarifConstraint);
                    }
                    return tarifMapper.mapToTarifResponseDto(tarif, tarifConstraintResponseDto);
                })
                .toList();
    }

    public TarifResponseDto findTarifResponseById(String id) {
        Tarif tarif = this.findById(id);
        TarifConstraint tarifConstraint = tarifConstraintService.findByTarifId(tarif.getId());
        TarifConstraintResponseDto tarifConstraintResponseDto = tarifConstraintMapper.mapToConstraintResponseDto(tarifConstraint);
        return tarifMapper.mapToTarifResponseDto(tarif, tarifConstraintResponseDto);
    }

    public Tarif findById(String id) {
        return tarifRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Tarif not found"));
    }
}
