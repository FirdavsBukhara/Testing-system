package uz.sinov.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.Tarif;
import uz.sinov.entity.TarifConstraint;
import uz.sinov.enums.TarifType;
import uz.sinov.mappers.TarifConstraintMapper;
import uz.sinov.payload.request.tarif.TarifConstraintCreateRequestDto;
import uz.sinov.repository.TarifConstraintRepository;

import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TarifConstraintService {
    private final TarifConstraintMapper tarifConstraintMapper;
    private final TarifConstraintRepository tarifConstraintRepository;

    public TarifConstraint findByTarifId(String tarifId) {
        return tarifConstraintRepository.findByTarifId(tarifId)
                .orElseThrow(() -> new IllegalArgumentException("Tarif constraint not found"));
    }

    public TarifConstraint findByTarifIdOrElseNull(String tarifId) {
        return tarifConstraintRepository.findByTarifId(tarifId)
                .orElse(null);
    }

    public String create(Tarif tarif, TarifConstraintCreateRequestDto request) {
        Optional<TarifConstraint> byTarifId = tarifConstraintRepository.findByTarifId(tarif.getId());
        if (byTarifId.isPresent()) {
            throw new IllegalArgumentException("Tarif constraint already exists");
        }

        if (Objects.equals(tarif.getType(), TarifType.ORGANIZATIONAL)) {
            if (Objects.isNull(request.getMaxOrganizationCount()) || request.getMaxOrganizationCount() <= 0) {
                throw new IllegalArgumentException("Organization count should be positive");
            }
            if (Objects.isNull(request.getMaxGroupCount()) || request.getMaxGroupCount() <= 0) {
                throw new IllegalArgumentException("Group count should be positive");
            }
        } else if (Objects.equals(tarif.getType(), TarifType.PERSONAL)) {
            if (Objects.isNull(request.getMaxTestCount()) || request.getMaxTestCount() <= 0) {
                throw new IllegalArgumentException("Test count should be positive");
            }
        }
        TarifConstraint tarifConstraint = tarifConstraintMapper.mapToTarifConstraint(tarif.getId(), request);

        tarifConstraintRepository.save(tarifConstraint);
        return "Tarif constraint created";
    }
}
