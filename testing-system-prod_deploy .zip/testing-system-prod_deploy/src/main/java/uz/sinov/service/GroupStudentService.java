package uz.sinov.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Group;
import uz.sinov.entity.GroupStudent;
import uz.sinov.entity.GroupTeacher;
import uz.sinov.entity.Organization;
import uz.sinov.entity.UserSubscription;
import uz.sinov.enums.GroupStudentStatus;
import uz.sinov.enums.UserSubscriptionStatus;
import uz.sinov.payload.request.group.GroupStudentAddRequestDto;
import uz.sinov.payload.request.group.GroupStudentRemoveRequestDto;
import uz.sinov.payload.response.group.GroupStudentResponseDto;
import uz.sinov.repository.GroupStudentRepository;
import uz.sinov.repository.GroupTeacherRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class GroupStudentService {

    private final SessionUser sessionUser;
    private final GroupService groupService;
    private final AuthUserService authUserService;
    private final OrganizationService organizationService;
    private final UserSubscriptionService userSubscriptionService;
    private final GroupStudentRepository groupStudentRepository;
    private final GroupTeacherRepository groupTeacherRepository;

    public String addStudentToGroup(GroupStudentAddRequestDto request) {
        String userId = sessionUser.id();
        AuthUser user = authUserService.findById(request.getUserId());
        Group group = groupService.findById(request.getGroupId());

        String organizationId = group.getOrganizationId();

        Organization organization = organizationService.findById(organizationId);

        final String directorId = organization.getDirectorId();

        UserSubscription userSubscription = userSubscriptionService.findByUserId(directorId);

        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionService.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }

        Optional<GroupStudent> groupStudentOptional = groupStudentRepository.findByGroupIdAndUserId(group.getId(), user.getId());
        if (groupStudentOptional.isPresent()) {
            throw new RuntimeException("Student already in group");
        }
        Optional<GroupTeacher> byGroupIdAndStudentId = groupTeacherRepository.findByGroupIdAndUserId(group.getId(), user.getId());
        if (byGroupIdAndStudentId.isPresent()) {
            throw new RuntimeException("Teacher can not be added as student");
        }

        Optional<GroupTeacher> optionalGroupTeacher = groupTeacherRepository.findByGroupIdAndUserId(group.getId(), userId);
        if (Objects.equals(userId, directorId) || optionalGroupTeacher.isPresent()) {
            GroupStudent groupStudent = GroupStudent.childBuilder()
                    .groupId(group.getId())
                    .userId(user.getId())
                    .status(GroupStudentStatus.IN)
                    .build();
            groupStudentRepository.save(groupStudent);
            return "Student added to group";
        } else {
            throw new RuntimeException("You have no permission to add student to group");
        }
    }

    public String removeFromGroup(GroupStudentRemoveRequestDto request) {
        String userId = sessionUser.id();
        AuthUser user = authUserService.findById(request.getUserId());
        Group group = groupService.findById(request.getGroupId());

        String organizationId = group.getOrganizationId();

        Organization organization = organizationService.findById(organizationId);

        final String directorId = organization.getDirectorId();

        UserSubscription userSubscription = userSubscriptionService.findByUserId(directorId);

        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionService.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }

        Optional<GroupStudent> groupStudentOptional = groupStudentRepository.findByGroupIdAndUserId(group.getId(), user.getId());
        if (groupStudentOptional.isEmpty()) {
            throw new RuntimeException("Student not in group");
        }

        Optional<GroupTeacher> optionalGroupTeacher = groupTeacherRepository.findByGroupIdAndUserId(group.getId(), userId);
        if (Objects.equals(userId, directorId) || optionalGroupTeacher.isPresent()) {
            GroupStudent groupStudent = groupStudentOptional.get();
            groupStudent.setStatus(GroupStudentStatus.NOT_IN);
            groupStudentRepository.save(groupStudent);
            return "Student removed from group";
        } else {
            throw new RuntimeException("You have no permission to remove student from group");
        }
    }

    public List<GroupStudentResponseDto> getAllGroupStudents(String groupId) {
        String userId = sessionUser.id();
        Group group = groupService.findById(groupId);
        return groupStudentRepository.findByGroupId(groupId)
                .stream()
                .map(groupStudent -> GroupStudentResponseDto.builder()
                        .id(groupStudent.getId())
                        .student(authUserService.findUserResponseById(groupStudent.getUserId()))
                        .groupId(groupStudent.getGroupId())
                        .status(groupStudent.getStatus())
                        .build()
                )
                .toList();
    }

    public Optional<GroupStudent> findByGroupIdAndUserId(String groupId, String userId) {
        return groupStudentRepository.findByGroupIdAndUserId(groupId, userId);
    }
}
