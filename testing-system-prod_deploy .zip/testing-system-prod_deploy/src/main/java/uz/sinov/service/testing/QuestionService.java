package uz.sinov.service.testing;


import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import uz.sinov.entity.Document;
import uz.sinov.entity.testing.Answer;
import uz.sinov.entity.testing.Question;
import uz.sinov.entity.testing.QuestionLevel;
import uz.sinov.entity.testing.Subject;
import uz.sinov.payload.request.PagingRequest;
import uz.sinov.payload.request.question.QuestionCreateRequestDto;
import uz.sinov.payload.request.question.QuestionPageRequestDto;
import uz.sinov.payload.response.PageableResponseDto;
import uz.sinov.payload.response.PagingResponse;
import uz.sinov.payload.response.question.QuestionResponseDto;
import uz.sinov.repository.QuestionRepository;
import uz.sinov.service.DocumentService;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuestionService {
    private final QuestionRepository questionRepository;
    private final SubjectService subjectService;
    private final DocumentService documentService;
    private final QuestionLevelService questionLevelService;
    private final AnswerService answerService;

    public String create(QuestionCreateRequestDto dto) {
        Subject subject = subjectService.findById(dto.getSubjectId());
        Document document = documentService.findByGeneratedNameOrElseNull(dto.getImgId());
        QuestionLevel questionLevel = questionLevelService.findById(dto.getQuestionLevelId());

        List<Answer> answers = answerService.createAnswers(dto.getAnswers());

        Question question = Question.childBuilder()
                .text(dto.getText())
                .imgId(dto.getImgId())
                .subject(subject)
                .questionLevel(questionLevel)
                .build();
        questionRepository.save(question);

        answerService.saveAll(answers, question.getId());

        return "Question created successfully";
    }

    public Question findById(String id) {
        return questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Question not found with id '%s'".formatted(id)));
    }

    public PageableResponseDto<QuestionResponseDto> findByPage(QuestionPageRequestDto request) {
        PagingRequest paging = request.getPaging();
        Sort sort = Sort.by(Sort.Direction.DESC, "createdAt");
        Pageable pageable = PageRequest.of(paging.getPage(), paging.getSize(), sort);

        Page<Question> questionPage = questionRepository.findByPage(request.getSubjectId(), pageable);

        List<QuestionResponseDto> questionResponseList = this.mapToResponse(questionPage.getContent());
        PagingResponse pagingResponse = PagingResponse.of(paging, (long) questionResponseList.size());

        return new PageableResponseDto<>(questionResponseList, pagingResponse);
    }

    public List<QuestionResponseDto> mapToResponse(List<Question> list) {
        return list.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public QuestionResponseDto mapToResponse(Question question) {
        return QuestionResponseDto.builder()
                .id(question.getId())
                .subjectId(question.getSubject().getId())
                .imgId(question.getImgId())
                .text(question.getText())
                .questionLevel(questionLevelService.mapToResponse(question.getQuestionLevel()))
                .answers(answerService.findResponseByQuestionId(question.getId()))
                .build();
    }

    public QuestionResponseDto findResponseById(String id) {
        Question question = this.findById(id);
        return this.mapToResponse(question);
    }

    public List<String> getRandomQuestionIds(Integer subjectId, List<QuestionLevel> questionLevels, Integer questionCount) {
        List<Question> randomQuestions = questionRepository.findRandomQuestions(subjectId, questionLevels, questionCount);
        return randomQuestions.stream()
                .map(Question::getId)
                .collect(Collectors.toList());
    }
}
