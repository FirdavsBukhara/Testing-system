package uz.sinov.service.testing;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.GroupStudent;
import uz.sinov.entity.testing.StudentTask;
import uz.sinov.entity.testing.Task;
import uz.sinov.enums.StudentTaskStatus;
import uz.sinov.payload.request.test_session.TestSessionCreateOrUpdateRequestDto;
import uz.sinov.payload.response.student_task.StudentTaskResponseDto;
import uz.sinov.payload.response.test_session.TestSessionResponseDto;
import uz.sinov.repository.GroupStudentRepository;
import uz.sinov.repository.StudentTaskRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentTaskService {
    private final GroupStudentRepository groupStudentRepository;
    private final TestSessionService testSessionService;
    private final StudentTaskRepository studentTaskRepository;

    public String create(Task task) {
        List<GroupStudent> groupStudents = groupStudentRepository.findByGroupId(task.getGroupId());
        List<StudentTask> studentTasks = new ArrayList<>();
        for (GroupStudent groupStudent : groupStudents) {
            TestSessionCreateOrUpdateRequestDto testSessionCreateRequestDto = new TestSessionCreateOrUpdateRequestDto(null);

            TestSessionResponseDto testSessionResponseDto = testSessionService.createTestSessionAndSave(
                    testSessionCreateRequestDto,
                    Collections.singletonList(task.getCriteria()),
                    groupStudent.getUserId()
            );

            StudentTask studentTask = StudentTask.childBuilder()
                    .task(task)
                    .studentId(groupStudent.getUserId())
                    .status(StudentTaskStatus.CREATED)
                    .groupId(task.getGroupId())
                    .testSessionId(testSessionResponseDto.getId())
                    .build();
            studentTasks.add(studentTask);
        }
        studentTaskRepository.saveAll(studentTasks);

        return "Student tasks created successfully";
    }

    public List<StudentTaskResponseDto> getAllByTaskId(String taskId) {
        List<StudentTask> studentTasks = studentTaskRepository.findByTaskId(taskId);
        return this.mapToResponseStudentTask(studentTasks);
    }

    public List<StudentTaskResponseDto> mapToResponseStudentTask(List<StudentTask> studentTasks) {
        return studentTasks.stream()
                .map(this::mapToResponseStudentTask)
                .toList();
    }

    public StudentTaskResponseDto mapToResponseStudentTask(StudentTask studentTask) {
        return StudentTaskResponseDto.builder()
                .id(studentTask.getId())
                .groupId(studentTask.getGroupId())
                .studentId(studentTask.getStudentId())
                .testSessionId(studentTask.getTestSessionId())
                .taskId(studentTask.getTask().getId())
                .status(studentTask.getStatus())
                .build();
    }
}
