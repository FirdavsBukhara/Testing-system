package uz.sinov.service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import uz.sinov.config.props.TwilioProps;

@Service
@RequiredArgsConstructor
public class TwilioService {
    private final TwilioProps twilioProps;

    @Async
    public void sendSMS(String toNumber, String sms) {
        Twilio.init(twilioProps.getSid(), twilioProps.getToken());
        String messageBody = "Your verification code is: " + sms;
        Message.creator(new PhoneNumber(toNumber),
                        new PhoneNumber(twilioProps.getFromNumber()),
                        messageBody)
                .create();
    }
}
