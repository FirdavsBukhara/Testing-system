package uz.sinov.service;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.UserSMS;
import uz.sinov.enums.SMSCodeType;
import uz.sinov.repository.UserSMSRepository;

import java.util.Objects;
import java.util.Random;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserSMSService {
    private final UserSMSRepository userSMSRepository;
    private final Random random;

    public UserSMS createSMSCode(AuthUser user, SMSCodeType type) {
        String userId = user.getId();
        UserSMS userSMS = this.findByUserId(userId, type);
        if (Objects.nonNull(userSMS)) {
            return userSMS;
        }
        String smsCode = String.valueOf(random.nextInt(100_000, 999_999));
        userSMS = this.buildAndSave(userId, smsCode, type);
        log.info("Sms created for user: '%s'  with code '%s'".formatted(user.getPhoneNumber(), smsCode));
        return userSMS;
    }

    private UserSMS buildAndSave(String userId, String smsCode, SMSCodeType type) {
        UserSMS userSMS = UserSMS.childBuilder()
                .userId(userId)
                .code(smsCode)
                .type(type)
                .build();
        return this.save(userSMS);
    }

    public UserSMS findByUserId(String userId, SMSCodeType type) {
        return userSMSRepository.findByUserId(userId, type);
    }

    public UserSMS save(UserSMS userSMS) {
        return userSMSRepository.save(userSMS);
    }
}
