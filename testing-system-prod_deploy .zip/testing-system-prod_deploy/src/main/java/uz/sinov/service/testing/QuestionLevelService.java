package uz.sinov.service.testing;


import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.testing.QuestionLevel;
import uz.sinov.payload.request.question_level.QuestionLevelCreateRequestDto;
import uz.sinov.payload.request.question_level.QuestionLevelListRequestDto;
import uz.sinov.payload.response.question_level.QuestionLevelResponseDto;
import uz.sinov.repository.QuestionLevelRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuestionLevelService {
    private final QuestionLevelRepository questionLevelRepository;

    public String create(QuestionLevelCreateRequestDto dto) {
        this.checkIfExistWithNameAndLevel(dto.getName(), dto.getLevel());
        QuestionLevel questionLevel = QuestionLevel.childBuilder()
                .name(dto.getName())
                .level(dto.getLevel())
                .score(dto.getScore())
                .description(dto.getDescription())
                .timeInSeconds(dto.getTimeInSeconds())
                .textColor(dto.getTextColor())
                .build();
        questionLevelRepository.save(questionLevel);
        return "Question level created successfully";
    }


    public List<QuestionLevelResponseDto> findAll() {
        List<QuestionLevel> questionLevels = questionLevelRepository.findAll();
        return this.mapToResponse(questionLevels);
    }


    public QuestionLevel findById(Integer id) {
        return questionLevelRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Question level not found with id: '%s'".formatted(id)));
    }

    public List<QuestionLevelResponseDto> mapToResponse(List<QuestionLevel> questionLevels) {
        return questionLevels.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public QuestionLevelResponseDto mapToResponse(QuestionLevel questionLevel) {
        return QuestionLevelResponseDto.builder()
                .id(questionLevel.getId())
                .name(questionLevel.getName())
                .level(questionLevel.getLevel())
                .score(questionLevel.getScore())
                .description(questionLevel.getDescription())
                .timeInSeconds(questionLevel.getTimeInSeconds())
                .textColor(questionLevel.getTextColor())
                .build();
    }


    private void checkIfExistWithNameAndLevel(String name, Integer level) {
        Optional<QuestionLevel> byNameAndLevel = questionLevelRepository.findByNameAndLevel(name, level);
        if (byNameAndLevel.isPresent()) {
            throw new RuntimeException("Question level exist with name: '%s' and level: '%s'".formatted(name, level));
        }
    }


    public List<QuestionLevel> findAllByIds(List<Integer> ids) {
        return questionLevelRepository.findByIdIn(ids);
    }

    public List<QuestionLevelResponseDto> findResponseAllByIds(QuestionLevelListRequestDto request) {
        List<QuestionLevel> questionLevels = this.findAllByIds(request.getIds());
        return this.mapToResponse(questionLevels);
    }
}
