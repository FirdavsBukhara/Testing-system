package uz.sinov.service.minio;

import io.minio.BucketExistsArgs;
import io.minio.GetObjectArgs;
import io.minio.GetObjectResponse;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.RemoveObjectArgs;
import io.minio.StatObjectArgs;
import io.minio.StatObjectResponse;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uz.sinov.config.props.MinIoProps;

import java.io.InputStream;

@Slf4j
@Getter
@Component
public class MinioConnector {

    private final MinioClient client;
    private final String bucket;

    public MinioConnector(MinIoProps prop) {
        this.bucket = prop.getBucket();
        this.client = MinioClient.builder()
                .endpoint(prop.getUrl())
                .credentials(prop.getAccessKey(), prop.getSecretKey())
                .build();
        this.createIfNotExists(this.bucket);
    }

    private void createIfNotExists(String bucket) {
        try {
            boolean b = client.bucketExists(BucketExistsArgs.builder()
                    .bucket(bucket)
                    .build());
            if (b) {
                return;
            }
            client.makeBucket(MakeBucketArgs.builder()
                    .bucket(bucket)
                    .build()
            );
        } catch (Exception e) {
            log.error("Error while creating bucket", e);
        }
    }

    public StatObjectResponse getMetaData(String fileName) {
        try {
            return client.statObject(StatObjectArgs.builder().bucket(this.bucket)
                    .object(fileName).build()
            );
        } catch (Exception e) {
            log.error("Error while getting metadata", e);
            return null;
        }
    }

    public void fileUpload(String fileName, long filesize, String contentType, InputStream fileInputStream) {
        try {
            client.putObject(PutObjectArgs.builder()
                    .bucket(this.bucket)
                    .object(fileName)
                    .stream(fileInputStream, filesize, -1)
                    .contentType(contentType)
                    .build()
            );

        } catch (Exception e) {
            log.error("Error while uploading file", e);
        }
    }

    public void fileDelete(String fileName) {
        try {
            client.removeObject(RemoveObjectArgs.builder().bucket(this.bucket)
                    .object(fileName).build());

        } catch (Exception e) {
            log.error("Error while deleting file", e);
        }
    }

    public GetObjectResponse getFile(String fileName) {
        try {
            return client.getObject(
                    GetObjectArgs.builder()
                            .bucket(this.bucket)
                            .object(fileName)
                            .build()
            );
        } catch (Exception e) {
            log.error("Error while getting file", e);
            return null;
        }
    }
}

