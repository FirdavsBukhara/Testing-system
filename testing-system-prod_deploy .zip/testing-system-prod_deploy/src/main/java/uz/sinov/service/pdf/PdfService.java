package uz.sinov.service.pdf;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import org.springframework.stereotype.Service;
import uz.sinov.payload.request.pdf.PdfOneQuestionDto;
import uz.sinov.payload.request.pdf.PdfParagraphDto;
import uz.sinov.payload.request.pdf.PdfSubjectDto;
import uz.sinov.utils.DateUtils;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class PdfService {
    public File generatePDF(PdfParagraphDto dto, List<PdfSubjectDto> subjects) throws IOException {
        File file = File.createTempFile("history", ".pdf");

        PdfDocument pdfDoc = new PdfDocument(new PdfWriter(file));
        Document doc = new Document(pdfDoc);

        String fullName = dto.getFullName();
        String phoneNumber = dto.getPhoneNumber();
        LocalDateTime startedAt = dto.getStartedAt();
        LocalDateTime finishedAt = dto.getFinishedAt();

        Paragraph paragraph = new Paragraph("Full name: " + fullName);
        doc.add(paragraph);
        paragraph = new Paragraph("Phone number: " + phoneNumber);
        doc.add(paragraph);
        paragraph = new Paragraph("Started at: " + DateUtils.formatDate(startedAt));
        doc.add(paragraph);
        paragraph = new Paragraph("Finished at: " + DateUtils.formatDate(finishedAt));
        doc.add(paragraph);
        paragraph = new Paragraph("Total score: %.5s".formatted(dto.getTotalScore()));
        doc.add(paragraph);

        for (PdfSubjectDto subject : subjects) {
            double score = this.calculateScore(subject.getQuestionList());
            paragraph = this.getParagraph("%s score: %.1f".formatted(subject.getSubjectName(), score));
            doc.add(paragraph);
            Table table = this.getTable();
            this.getReadyTable(table, subject.getQuestionList());
            doc.add(table);
        }
        doc.close();
        return file;
    }

    private double calculateScore(List<PdfOneQuestionDto> questionList) {
        return questionList.stream()
                .filter(PdfOneQuestionDto::isCorrect)
                .mapToDouble(PdfOneQuestionDto::getScore)
                .sum();

    }

    private Table getTable() {
        Table table = new Table(new float[]{2, 1, 1, 1, 1, 2, 1, 1, 1, 1});
        table.setWidth(PageSize.A4.getWidth() - 50);
        table.setBorder(new SolidBorder(ColorConstants.WHITE, 0));
        return table;
    }

    private Paragraph getParagraph(String paragraphName) {
        Paragraph paragraph = new Paragraph(paragraphName);
        paragraph.setTextAlignment(TextAlignment.CENTER);
        paragraph.setBold();
        paragraph.setFontSize(20);
        return paragraph;
    }

    private void getReadyTable(Table table, List<PdfOneQuestionDto> list) {
        StringBuilder result;
        for (int i = 0; i < list.size(); i++) {
            PdfOneQuestionDto questionDto = list.get(i);
            result = new StringBuilder((i + 1) + " . ");
            if (questionDto != null && questionDto.isCorrect()) {
                result.append("T - %s".formatted(questionDto.getScore()));
            } else {
                result.append("F - 0");
            }
            Cell cell = new Cell();
            cell.setTextAlignment(TextAlignment.CENTER);
            cell.add(new Paragraph(result.toString()).setBold());
            table.addCell(cell);
        }
    }
}