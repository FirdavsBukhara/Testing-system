package uz.sinov.service;


import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.JwtService;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Role;
import uz.sinov.entity.UserSMS;
import uz.sinov.enums.SMSCodeType;
import uz.sinov.enums.TokenType;
import uz.sinov.enums.UserStatus;
import uz.sinov.mappers.UserMapper;
import uz.sinov.payload.request.auth.RefreshTokenRequestDto;
import uz.sinov.payload.request.auth.TokenRequestDto;
import uz.sinov.payload.request.auth.UserActivateRequestDto;
import uz.sinov.payload.request.auth_user.AuthUserResponseDTO;
import uz.sinov.payload.request.auth_user.ResendCodeRequestDto;
import uz.sinov.payload.request.auth_user.RoleResponseDto;
import uz.sinov.payload.request.auth_user.UserCreateRequestDto;
import uz.sinov.payload.response.auth.TokenResponseDto;
import uz.sinov.payload.response.auth.UserResponseDto;
import uz.sinov.repository.AuthUserRepository;
import uz.sinov.repository.RoleRepository;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthUserService {
    private final AuthenticationManager authenticationManager;
    private final AuthUserRepository authUserRepository;
    private final UserSMSService userSMSService;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;
    private final RoleRepository roleRepository;
    private final SessionUser sessionUser;

    public AuthUser create(UserCreateRequestDto dto) {
        this.checkUserExist(dto.getPhoneNumber());
        this.checkPassword(dto.getPassword(), dto.getConfirmPassword());
        Optional<Role> roleOptional = roleRepository.findByName("USER");
        AuthUser authUser = AuthUser.childBuilder()
                .name(dto.getName())
                .phoneNumber(dto.getPhoneNumber())
                .password(passwordEncoder.encode(dto.getPassword()))
                .status(UserStatus.NO_ACTIVE)
                .role(roleOptional.orElse(null))
                .build();
        authUserRepository.save(authUser);
        UserSMS smsCode = userSMSService.createSMSCode(authUser, SMSCodeType.ACTIVATION);
        // send sms here
        return authUser;
    }

    public TokenResponseDto generateToken(TokenRequestDto tokenRequest) {
        String phoneNumber = tokenRequest.phoneNumber();
        String password = tokenRequest.password();
        this.findActiveByPhone(phoneNumber);
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(phoneNumber, password);
        authenticationManager.authenticate(authentication);
        return jwtService.generateToken(phoneNumber);
    }

    public AuthUser findActiveByPhone(String phone) {
        return authUserRepository.findActiveByPhoneNumber(phone)
                .orElseThrow(() -> new RuntimeException("User not found with phone '%s'".formatted(phone)));
    }

    public AuthUser findByPhone(String phone) {
        return authUserRepository.findByPhoneNumber(phone)
                .orElseThrow(() -> new RuntimeException("User not found with phone '%s'".formatted(phone)));
    }


    public TokenResponseDto refreshToken(RefreshTokenRequestDto refreshTokenRequest) {
        String refreshToken = refreshTokenRequest.getRefreshToken();
        if (!jwtService.isTokenValid(refreshToken, TokenType.REFRESH))
            throw new CredentialsExpiredException("Token is invalid");

        String phoneNumber = jwtService.getUsername(refreshToken, TokenType.REFRESH);
        this.findActiveByPhone(phoneNumber);
        TokenResponseDto tokenResponse = TokenResponseDto.builder()
                .refreshToken(refreshToken)
                .build();
        return jwtService.generateAccessToken(phoneNumber, tokenResponse);
    }

    public Boolean activate(UserActivateRequestDto dto) {
        String phoneNumber = dto.phoneNumber();
        String code = dto.code();
        AuthUser user = this.findByPhone(phoneNumber);
        if (UserStatus.ACTIVE.equals(user.getStatus())) {
            throw new RuntimeException("User active already");
        }
        if (code.equalsIgnoreCase("000000")) {
            user.setStatus(UserStatus.ACTIVE);
            authUserRepository.save(user);
            return true;
        }//TODO after adding sms service remove this code fragment

        UserSMS userSMS = userSMSService.findByUserId(user.getId(), SMSCodeType.ACTIVATION);
        if ((!Objects.isNull(userSMS) && userSMS.getCode().equals(code))) {
            userSMS.setExpired(true);
            userSMSService.save(userSMS);
            user.setStatus(UserStatus.ACTIVE);
            authUserRepository.save(user);
            return true;
        }
        throw new RuntimeException("Code is invalid");
    }

    public void resendCode(ResendCodeRequestDto dto) {
        AuthUser user = this.findByPhone(dto.getPhoneNumber());
        userSMSService.createSMSCode(user, dto.getSmsCodeType());
    }

    public AuthUser findById(String userId) {
        return authUserRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id '%s'".formatted(userId)));
    }

    public UserResponseDto findUserResponseById(String userId) {
        AuthUser user = this.findById(userId);
        return userMapper.mapToDirectorResponse(user);
    }

    private void checkPassword(String password, String confirmPassword) {
        if (!Objects.equals(password, confirmPassword)) {
            throw new RuntimeException("Password and confirm password must be the same");
        }
    }

    private void checkUserExist(String phoneNumber) {
        Optional<AuthUser> byUsername = authUserRepository.findByPhoneNumber(phoneNumber);
        if (byUsername.isPresent()) {
            throw new RuntimeException("User already exists");
        }
    }

    public void save(AuthUser user) {
        authUserRepository.save(user);
    }

    public AuthUserResponseDTO getProfile() {
        String userId = sessionUser.id();
        AuthUser user = this.findById(userId);
        return AuthUserResponseDTO.builder()
                .id(user.getId())
                .name(user.getName())
                .phoneNumber(user.getPhoneNumber())
                .profileImg(user.getProfileImg())
                .role(this.mapToResponseRole(user.getRole()))
                .status(user.getStatus())
                .balance(user.getBalance())
                .build();
    }

    private RoleResponseDto mapToResponseRole(Role role) {
        if (Objects.isNull(role)) {
            return new RoleResponseDto();
        }
        return RoleResponseDto.builder()
                .id(role.getId())
                .name(role.getName())
                .description(role.getDescription())
                .permissions(Objects.requireNonNullElse(role.getPermissions(), Collections.emptyList()))
                .build();
    }
}
