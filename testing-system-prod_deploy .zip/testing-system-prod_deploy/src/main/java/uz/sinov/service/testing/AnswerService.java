package uz.sinov.service.testing;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.testing.Answer;
import uz.sinov.payload.request.answers.AnswerCreateRequestDto;
import uz.sinov.payload.response.answers.AnswerResponseDto;
import uz.sinov.repository.AnswerRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnswerService {
    private final AnswerRepository answerRepository;

    public List<Answer> createAnswers(List<AnswerCreateRequestDto> answers) {
        this.checkAnswers(answers);
        List<Answer> answerList = answers.stream()
                .map(answerCreateDTO -> Answer.builder()
                        .text(answerCreateDTO.getText())
                        .isCorrect(answerCreateDTO.isCorrect())
                        .build())
                .collect(Collectors.toList());
        return answerRepository.saveAll(answerList);
    }

    private void checkAnswers(List<AnswerCreateRequestDto> answers) {
        if (answers.size() < 2) {
            throw new RuntimeException("At least two answers are required");
        }
        long correctCount = answers.stream()
                .filter(AnswerCreateRequestDto::isCorrect)
                .count();
        if (correctCount != 1) {
            throw new RuntimeException("Only one correct answer is allowed");
        }
    }

    public List<AnswerResponseDto> findResponseByQuestionId(String questionId) {
        List<Answer> answers = answerRepository.findByQuestionId(questionId);
        return this.mapToResponse(answers);
    }

    public List<AnswerResponseDto> mapToResponse(List<Answer> answers) {
        return answers.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public AnswerResponseDto mapToResponse(Answer answer) {
        return AnswerResponseDto.builder()
                .id(answer.getId())
                .text(answer.getText())
                .questionId(answer.getQuestionId())
                .build();
    }

    public Answer findCorrectByQuestionId(String questionId) {
        return answerRepository.findByQuestionIdAndIsCorrect(questionId, true)
                .orElse(null);
    }

    public void saveAll(List<Answer> answers, String questionId) {
        answers.forEach(answer -> answer.setQuestionId(questionId));
        answerRepository.saveAll(answers);
    }
}
