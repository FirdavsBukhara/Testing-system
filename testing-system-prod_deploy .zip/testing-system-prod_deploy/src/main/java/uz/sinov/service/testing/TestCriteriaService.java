package uz.sinov.service.testing;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.entity.testing.QuestionLevel;
import uz.sinov.entity.testing.Subject;
import uz.sinov.entity.testing.TestCriteria;
import uz.sinov.entity.testing.TestSession;
import uz.sinov.payload.request.test_session.TestCriteriaCreateRequestDto;
import uz.sinov.payload.response.question_level.QuestionLevelResponseDto;
import uz.sinov.payload.response.test_session.TestCriteriaResponseDto;
import uz.sinov.repository.TestCriteriaRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TestCriteriaService {
    private final QuestionLevelService questionLevelService;
    private final SubjectService subjectService;
    private final TestCriteriaRepository testCriteriaRepository;

    public List<TestCriteriaResponseDto> mapToResponseTestCriteria(List<TestCriteria> criteria) {
        return criteria.stream()
                .map(this::mapToResponseTestCriteria)
                .toList();
    }

    public TestCriteriaResponseDto mapToResponseTestCriteria(TestCriteria criteria) {
        List<QuestionLevelResponseDto> questionLevels = questionLevelService.mapToResponse(criteria.getQuestionLevel());
        return TestCriteriaResponseDto.builder()
                .id(criteria.getId())
                .subjectId(criteria.getSubject().getId())
                .questionLevels(questionLevels)
                .questionCount(criteria.getQuestionCount())
                .build();
    }

    public List<TestCriteria> mapToTestCriteria(List<TestCriteriaCreateRequestDto> requestCriteria) {
        return requestCriteria.stream()
                .map(this::mapToTestCriteria)
                .toList();
    }

    public TestCriteria mapToTestCriteria(TestCriteriaCreateRequestDto requestCriteria) {
        Subject subject = subjectService.findById(requestCriteria.getSubjectId());
        List<QuestionLevel> questionLevels = questionLevelService.findAllByIds(requestCriteria.getQuestionLevels());
        return TestCriteria.childBuilder()
                .subject(subject)
                .questionLevel(questionLevels)
                .questionCount(requestCriteria.getQuestionCount())
                .build();
    }

    public void saveAll(List<TestCriteria> criteriaList, TestSession testSession) {
        for (TestCriteria criteria : criteriaList) {
            criteria.setTestSession(testSession);
        }
        testCriteriaRepository.saveAll(criteriaList);
    }
}
