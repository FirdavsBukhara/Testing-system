package uz.sinov.service;

import io.minio.GetObjectResponse;
import io.minio.StatObjectResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import uz.sinov.entity.Document;
import uz.sinov.repository.DocumentRepository;
import uz.sinov.service.minio.MinioConnector;
import uz.sinov.utils.BaseUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DocumentService {
    private final DocumentRepository documentRepository;
    private final MinioConnector minioConnector;

    private final Set<String> extensionsList = Set.of(
            "doc", "docx",
            "xls", "xlsx",
            "pdf"
    );

    public Document findByGeneratedName(String generatedName) {
        return documentRepository.findByGeneratedName(generatedName)
                .orElseThrow(() -> new RuntimeException("Document not found with name '%s'".formatted(generatedName)));
    }

    public Document findByGeneratedNameOrElseNull(String generatedName) {
        return documentRepository.findByGeneratedName(generatedName)
                .orElse(null);
    }

    public Document saveMultipartDocument(MultipartFile file) throws IOException {
        String originalFilename = Objects.requireNonNullElse(file.getOriginalFilename(), Timestamp.valueOf(LocalDateTime.now()) + ".png");
        String extension = BaseUtils.getExtension(originalFilename);
        String uuid = UUID.randomUUID().toString();
        String generatedName = uuid + extension;
        String contentType = file.getContentType();
        Document document = Document.childBuilder()
                .contentType(contentType)
                .uuid(uuid)
                .generatedName(generatedName)
                .extension(extension)
                .originalName(originalFilename)
                .size(file.getSize())
                .filePath("static/%s".formatted(generatedName))
                .build();
        documentRepository.save(document);
        minioConnector.fileUpload(generatedName, file.getSize(), contentType, file.getInputStream());
        return document;
    }

    public Document savePdfFile(File file) {
        String originalFilename = Objects.requireNonNullElse(file.getName(), Timestamp.valueOf(LocalDateTime.now()) + ".pdf");
        String extension = BaseUtils.getExtension(originalFilename);
        String uuid = UUID.randomUUID().toString();
        String generatedName = uuid + extension;
        Document document = Document.childBuilder()
                .originalName(originalFilename)
                .generatedName(generatedName)
                .extension(extension)
                .contentType("application/pdf")
                .size(file.length())
                .filePath("static/%s".formatted(generatedName))
                .build();
        documentRepository.save(document);

        try {
            minioConnector.fileUpload(generatedName,
                    document.getSize(),
                    document.getContentType(),
                    new FileInputStream(file));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return document;
    }

    public ResponseEntity<InputStreamResource> downloadByGeneratedName(String name) {
        Document document = this.findByGeneratedName(name);
        StatObjectResponse metaData = minioConnector.getMetaData(name);
        GetObjectResponse objectResponse = minioConnector.getFile(name);
        InputStreamResource resource = new InputStreamResource(objectResponse);
        if (this.extensionsList.contains(document.getExtension())) {
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + document.getOriginalName())
                    .contentLength(document.getSize())
                    .contentType(MediaType.parseMediaType(metaData.contentType()))
                    .body(resource);
        } else {
            String contentType = metaData.contentType();
            if (contentType.contains("*")) {
                contentType = contentType.replace("*", document.getExtension());
            }
            return ResponseEntity
                    .ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);
        }
    }
}
