package uz.sinov.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.UserSubscription;
import uz.sinov.enums.TarifStatus;
import uz.sinov.enums.UserSubscriptionStatus;
import uz.sinov.mappers.UserSubscriptionMapper;
import uz.sinov.payload.request.user_subscribe.UserSubscribeRequestDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;
import uz.sinov.payload.response.user_subscribe.UserSubscriptionResponseDto;
import uz.sinov.repository.UserSubscriptionRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserSubscriptionService {
    private final AuthUserService authUserService;
    private final SessionUser sessionUser;
    private final UserSubscriptionRepository userSubscriptionRepository;
    private final TarifService tarifService;
    private final UserSubscriptionMapper userSubscriptionMapper;

    public String disableMySubscription() {
        String userId = sessionUser.id();
        this.findAndDisableSubscriptionByUserId(userId);
        return "User subscription disabled";
    }

    public String disableUserSubscription(String userId) {
        authUserService.findById(userId);
        this.findAndDisableSubscriptionByUserId(userId);
        return "User subscription disabled";
    }

    private void findAndDisableSubscriptionByUserId(String userId) {
        UserSubscription userSubscription = this.findByUserId(userId);

        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            throw new IllegalArgumentException("User subscription already expired");
        }
        userSubscription.setStatus(UserSubscriptionStatus.NO_ACTIVE);
        userSubscriptionRepository.save(userSubscription);
    }

    public String subscribe(UserSubscribeRequestDto request) {
        String userId = sessionUser.id();
        AuthUser user = authUserService.findById(userId);
        Optional<UserSubscription> byUserId = userSubscriptionRepository.findByUserId(userId);
        LocalDate now = LocalDate.now();
        if (byUserId.isPresent()) {
            UserSubscription userSubscription = byUserId.get();
            if (Objects.equals(userSubscription.getStatus(), UserSubscriptionStatus.ACTIVE) &&
                    userSubscription.getToTime().isAfter(now)) {
                throw new IllegalArgumentException("You have active subscription");
            }
        }
        TarifResponseDto tarifResponseById = tarifService.findTarifResponseById(request.getTarifId());
        TarifConstraintResponseDto tarifConstraintResponseDto = tarifResponseById.getConstraint();
        if (!Objects.equals(tarifResponseById.getStatus(), TarifStatus.ACTIVE)) {
            throw new IllegalArgumentException("Tarif not active");
        }
        if (tarifResponseById.getFromTime().isAfter(now)) {
            throw new IllegalArgumentException("Tarif not started yet");
        }
        if (tarifResponseById.getToTime().isBefore(now)) {
            throw new IllegalArgumentException("Tarif already expired");
        }
        if (tarifResponseById.getPrice() > user.getBalance()) {
            throw new IllegalArgumentException("Not enough balance");
        }

        long userSubscriptionCount = userSubscriptionRepository.countByUserIdAndTarifId(userId, request.getTarifId());

        if (userSubscriptionCount >= tarifConstraintResponseDto.getMaxBuyCount()) {
            throw new IllegalArgumentException("User already subscribed to this tarif too much");
        }

        user.setBalance(user.getBalance() - tarifResponseById.getPrice());
        authUserService.save(user);

        UserSubscription userSubscription = UserSubscription.childBuilder()
                .userId(userId)
                .tarifId(request.getTarifId())
                .fromTime(now)
                .toTime(now.plusDays(tarifConstraintResponseDto.getPeriodInDays()))
                .status(UserSubscriptionStatus.ACTIVE)
                .build();
        userSubscriptionRepository.save(userSubscription);
        //grant role here depend on tarif
        return "User subscribed successfully";
    }

    public UserSubscription findByUserId(String userId) {
        return userSubscriptionRepository.findByUserId(userId)
                .orElseThrow(() -> new IllegalArgumentException("User subscription not found"));
    }

    public List<UserSubscriptionResponseDto> getMySubscriptions() {
        String userId = sessionUser.id();
        return this.getUserSubscriptions(userId);
    }

    public List<UserSubscriptionResponseDto> getUserSubscriptions(String userId) {
        authUserService.findById(userId);
        List<UserSubscription> userSubscriptions = userSubscriptionRepository.findAllByUserId(userId);
        return userSubscriptionMapper.mapToDto(userSubscriptions);
    }

    public void save(UserSubscription userSubscription) {
        userSubscriptionRepository.save(userSubscription);
    }

    public UserSubscription checkUserSubscription(String userId) {
        UserSubscription userSubscription = userSubscriptionRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("User has no subscription"));

        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionRepository.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }
        return userSubscription;
    }
}
