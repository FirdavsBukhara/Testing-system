package uz.sinov.service.testing;


import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.testing.Subject;
import uz.sinov.enums.SubjectType;
import uz.sinov.payload.request.subject.SubjectCreateRequestDto;
import uz.sinov.payload.response.subject.SubjectResponseDto;
import uz.sinov.repository.GroupTeacherRepository;
import uz.sinov.repository.SubjectRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SubjectService {
    private final SubjectRepository subjectRepository;
    private final SessionUser sessionUser;
    private final GroupTeacherRepository groupTeacherRepository;

    public String create(@NotNull SubjectCreateRequestDto dto) {
        String userId = sessionUser.id();
        boolean b = groupTeacherRepository.existsByUserId(userId);

        Subject subject = Subject.childBuilder()
                .name(dto.getName())
                .description(dto.getDescription())
                .type(b ? SubjectType.PRIVATE : SubjectType.GLOBAL)
                .build();
        subjectRepository.save(subject);
        return "Subject created successfully";
    }

    public List<SubjectResponseDto> findAll() {
        List<Subject> subjects = subjectRepository.findAll();
        return this.mapToResponse(subjects);
    }

    public List<SubjectResponseDto> mapToResponse(List<Subject> subjects) {
        return subjects.stream()
                .map(this::mapToResponse)
                .toList();
    }

    public SubjectResponseDto mapToResponse(Subject subject) {
        return SubjectResponseDto.builder()
                .id(subject.getId())
                .name(subject.getName())
                .description(subject.getDescription())
                .build();
    }

    public Subject findById(Integer id) {
        return subjectRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Subject not found with id '%s'".formatted(id)));
    }

    public SubjectResponseDto findResponseById(Integer id) {
        Subject subject = this.findById(id);
        return this.mapToResponse(subject);
    }
}
