package uz.sinov.service;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Group;
import uz.sinov.entity.Organization;
import uz.sinov.entity.UserSubscription;
import uz.sinov.enums.TarifType;
import uz.sinov.enums.UserStatus;
import uz.sinov.enums.UserSubscriptionStatus;
import uz.sinov.payload.request.group.GroupAddRequestDto;
import uz.sinov.payload.response.group.GroupResponseDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;
import uz.sinov.repository.GroupRepository;
import uz.sinov.repository.GroupStudentRepository;
import uz.sinov.repository.GroupTeacherRepository;
import uz.sinov.repository.OrganizationRepository;
import uz.sinov.repository.UserSubscriptionRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GroupService {
    private final SessionUser sessionUser;
    private final AuthUserService authUserService;
    private final UserSubscriptionRepository userSubscriptionRepository;
    private final TarifService tarifService;
    private final OrganizationRepository organizationRepository;
    private final GroupRepository groupRepository;
    private final GroupStudentRepository groupStudentRepository;
    private final GroupTeacherRepository groupTeacherRepository;
    private final OrganizationService organizationService;

    public String addGroup(GroupAddRequestDto request) {
        String userId = sessionUser.id();
        AuthUser user = authUserService.findById(userId);

        if (!Objects.equals(user.getStatus(), UserStatus.ACTIVE)) {
            throw new RuntimeException("User is not active");
        }

        Organization organization = organizationRepository.findById(request.getOrganizationId())
                .orElseThrow(() -> new RuntimeException("Organization not found"));

        AuthUser director = authUserService.findById(organization.getDirectorId());
        UserSubscription userSubscription = userSubscriptionRepository.findByUserId(director.getId())
                .orElseThrow(() -> new RuntimeException("Your organization has no subscription"));

        if (!Objects.equals(userSubscription.getStatus(), UserSubscriptionStatus.ACTIVE)) {
            throw new RuntimeException("Subscription is not active");
        }

        TarifResponseDto tarifResponseById = tarifService.findTarifResponseById(userSubscription.getTarifId());
        TarifConstraintResponseDto tarifConstraintResponseDto = tarifResponseById.getConstraint();

        if (!Objects.equals(tarifResponseById.getType(), TarifType.ORGANIZATIONAL)) {
            throw new RuntimeException("You have no permission to add group");
        }
        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionRepository.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }

        short maxGroupCount = tarifConstraintResponseDto.getMaxGroupCount();
        short groupCount = groupRepository.countByOrganizationId(organization.getId());
        if (groupCount >= maxGroupCount) {
            throw new RuntimeException("You have reached the maximum number of groups to this organization");
        }

        Group group = Group.childBuilder()
                .description(request.getDescription())
                .name(request.getName())
                .organizationId(request.getOrganizationId())
                .specialization(request.getSpecialization())
                .build();

        groupRepository.save(group);

        return "Group added successfully";
    }

    public List<GroupResponseDto> getMyGroups() {
        final String userId = sessionUser.id();
        List<Group> groups = groupRepository.findAllActive();
        groups = groups.stream()
                .filter(g -> groupStudentRepository.existsByUserIdAndGroupId(userId, g.getId()) ||
                        groupTeacherRepository.existsByUserIdAndGroupId(userId, g.getId())
                )
                .collect(Collectors.toList());
        return this.mapToGroupResponseDtoList(groups);
    }

    private List<GroupResponseDto> mapToGroupResponseDtoList(List<Group> groups) {
        return groups.stream()
                .map(group -> GroupResponseDto.builder()
                        .id(group.getId())
                        .organization(organizationService.organizationResponseById(group.getOrganizationId()))
                        .name(group.getName())
                        .description(group.getDescription())
                        .specialization(group.getSpecialization())
                        .build())
                .collect(Collectors.toList());
    }

    public Group findById(String groupId) {
        return groupRepository.findById(groupId)
                .orElseThrow(() -> new EntityNotFoundException("Group not found"));
    }

    public List<GroupResponseDto> getMyOrganizationGroups(String orgId) {
        String userId = sessionUser.id();
        Organization organization = organizationRepository.findByIdAndDirectorId(orgId, userId)
                .orElseThrow(() -> new EntityNotFoundException("Organization not found"));
        List<Group> groups = groupRepository.findByOrganizationId(orgId);
        return this.mapToGroupResponseDtoList(groups);
    }
}
