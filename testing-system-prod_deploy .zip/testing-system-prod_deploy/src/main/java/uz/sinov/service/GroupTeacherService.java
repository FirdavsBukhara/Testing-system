package uz.sinov.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Group;
import uz.sinov.entity.GroupStudent;
import uz.sinov.entity.GroupTeacher;
import uz.sinov.entity.Organization;
import uz.sinov.entity.UserSubscription;
import uz.sinov.enums.GroupTeacherStatus;
import uz.sinov.enums.UserSubscriptionStatus;
import uz.sinov.payload.request.group.GroupTeacherAddRequestDto;
import uz.sinov.payload.request.group.GroupTeacherRemoveRequestDto;
import uz.sinov.payload.response.group.GroupTeacherResponseDto;
import uz.sinov.repository.GroupStudentRepository;
import uz.sinov.repository.GroupTeacherRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class GroupTeacherService {
    private final GroupTeacherRepository groupTeacherRepository;
    private final SessionUser sessionUser;
    private final AuthUserService authUserService;
    private final GroupService groupService;
    private final OrganizationService organizationService;
    private final UserSubscriptionService userSubscriptionService;
    private final GroupStudentRepository groupStudentRepository;

    public String addTeacherToGroup(GroupTeacherAddRequestDto request) {
        String userId = sessionUser.id();
        AuthUser user = authUserService.findById(request.getUserId());
        Group group = groupService.findById(request.getGroupId());

        String organizationId = group.getOrganizationId();

        Organization organization = organizationService.findById(organizationId);

        final String directorId = organization.getDirectorId();

        UserSubscription userSubscription = userSubscriptionService.findByUserId(directorId);

        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionService.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }

        Optional<GroupTeacher> groupTeacherOptional = groupTeacherRepository.findByGroupIdAndUserId(group.getId(), user.getId());
        if (groupTeacherOptional.isPresent()) {
            throw new RuntimeException("Teacher already in group");
        }

        Optional<GroupStudent> groupStudentOptional1 = groupStudentRepository.findByGroupIdAndUserId(group.getId(), user.getId());
        if (groupStudentOptional1.isPresent()) {
            throw new RuntimeException("Student can not be added as teacher");
        }

        if (Objects.equals(userId, directorId)) {
            GroupTeacher groupTeacher = GroupTeacher.childBuilder()
                    .groupId(group.getId())
                    .userId(user.getId())
                    .status(GroupTeacherStatus.IN)
                    .build();
            groupTeacherRepository.save(groupTeacher);
            return "Teacher added to group";
        } else {
            throw new RuntimeException("You have no permission to add teacher to group");
        }
    }

    public String removeFromGroup(GroupTeacherRemoveRequestDto request) {
        String userId = sessionUser.id();
        AuthUser user = authUserService.findById(request.getUserId());
        Group group = groupService.findById(request.getGroupId());

        String organizationId = group.getOrganizationId();

        Organization organization = organizationService.findById(organizationId);

        final String directorId = organization.getDirectorId();

        UserSubscription userSubscription = userSubscriptionService.findByUserId(directorId);

        if (userSubscription.getToTime().isBefore(LocalDate.now())) {
            userSubscription.setStatus(UserSubscriptionStatus.EXPIRED);
            userSubscriptionService.save(userSubscription);
            throw new RuntimeException("Subscription has expired");
        }

        Optional<GroupTeacher> groupTeacherOptional = groupTeacherRepository.findByGroupIdAndUserId(group.getId(), user.getId());
        if (groupTeacherOptional.isEmpty()) {
            throw new RuntimeException("Teacher not in group");
        }

        if (Objects.equals(userId, directorId)) {
            GroupTeacher groupStudent = groupTeacherOptional.get();
            groupStudent.setStatus(GroupTeacherStatus.NOT_IN);
            groupTeacherRepository.save(groupStudent);
            return "Teacher removed from group";
        } else {
            throw new RuntimeException("You have no permission to add student to group");
        }
    }

    public List<GroupTeacherResponseDto> getAllGroupTeachers(String groupId) {
        String userId = sessionUser.id();
        Group group = groupService.findById(groupId);
        return groupTeacherRepository.findByGroupId(groupId)
                .stream()
                .map(gt -> GroupTeacherResponseDto.builder()
                        .id(gt.getId())
                        .teacher(authUserService.findUserResponseById(gt.getUserId()))
                        .groupId(gt.getGroupId())
                        .status(gt.getStatus())
                        .teacherSpecialization(gt.getTeacherSpecialization())
                        .build()
                )
                .toList();
    }
}
