package uz.sinov.service.testing;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.testing.SolveQuestion;
import uz.sinov.entity.testing.Subject;
import uz.sinov.entity.testing.TestCriteria;
import uz.sinov.entity.testing.TestSession;
import uz.sinov.enums.TestSessionStatus;
import uz.sinov.payload.request.solve_question.SolveQuestionListUpdateRequestDto;
import uz.sinov.payload.request.solve_question.SolveQuestionUpdateRequestDto;
import uz.sinov.payload.response.solve_question.RemainQuestionCountResponseDto;
import uz.sinov.repository.SolveQuestionRepository;
import uz.sinov.repository.TestSessionRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class SolveQuestionService {
    private final SolveQuestionRepository solveQuestionRepository;
    private final QuestionService questionService;
    private final TestSessionRepository testSessionRepository;
    private final SessionUser sessionUser;

    public List<SolveQuestion> create(TestSession testSession) {
        List<TestCriteria> criteria = testSession.getCriteria();
        List<SolveQuestion> solveQuestions = new ArrayList<>();
        for (TestCriteria cr : criteria) {
            Subject subject = cr.getSubject();
            List<String> questionIds = questionService.getRandomQuestionIds(subject.getId(), cr.getQuestionLevel(), cr.getQuestionCount());
            for (String questionId : questionIds) {
                SolveQuestion solveQuestion = SolveQuestion.builder()
                        .testSession(testSession)
                        .questionId(questionId)
                        .subjectId(subject.getId())
                        .build();
                solveQuestions.add(solveQuestion);
            }
        }
        return solveQuestionRepository.saveAll(solveQuestions);
    }

    public List<SolveQuestion> findAllByTestSessionId(String testSessionId) {
        return solveQuestionRepository.findAllByTestSessionId(testSessionId);
    }

    public RemainQuestionCountResponseDto updateSolveQuestion(SolveQuestionListUpdateRequestDto request) {
        String testSessionId = request.getTestSessionId();
        String userId = sessionUser.id();
        TestSession testSession = testSessionRepository.findByUserIdAndId(userId, testSessionId)
                .orElseThrow(() -> new RuntimeException("Test session not found"));
        if (Objects.equals(testSession.getStatus(), TestSessionStatus.FINISHED)) {
            throw new RuntimeException("Test session already finished");
        }

        if (Objects.equals(testSession.getStatus(), TestSessionStatus.CREATED)) {
            throw new RuntimeException("Test session not started yet");
        }

        List<SolveQuestionUpdateRequestDto> solveQuestions = request.getQuestions();
        for (SolveQuestionUpdateRequestDto requestDto : solveQuestions) {
            try {
                solveQuestionRepository.updateByIdAndTestSessionId(
                        testSessionId,
                        requestDto.getSolveQuestionId(),
                        requestDto.getUserAnswerId()
                );
            } catch (Exception exception) {
                log.error("Error while updating solve question", exception);
            }
        }
        int remainQuestionCount = solveQuestionRepository.countUnmarkedByTestSessionId(testSessionId);
        return new RemainQuestionCountResponseDto(remainQuestionCount);
    }
}
