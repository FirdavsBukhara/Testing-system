package uz.sinov.service.testing;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.UserSubscription;
import uz.sinov.entity.testing.Answer;
import uz.sinov.entity.testing.QuestionLevel;
import uz.sinov.entity.testing.SolveQuestion;
import uz.sinov.entity.testing.StudentTask;
import uz.sinov.entity.testing.Subject;
import uz.sinov.entity.testing.TestCriteria;
import uz.sinov.entity.testing.TestSession;
import uz.sinov.enums.StudentTaskStatus;
import uz.sinov.enums.TarifType;
import uz.sinov.enums.TestSessionStatus;
import uz.sinov.payload.request.test_session.TestCriteriaCreateRequestDto;
import uz.sinov.payload.request.test_session.TestSessionCreateOrUpdateRequestDto;
import uz.sinov.payload.request.test_session.TestSessionIdRequestDto;
import uz.sinov.payload.response.question.QuestionResponseDto;
import uz.sinov.payload.response.solve_question.SolveQuestionResponseDto;
import uz.sinov.payload.response.solve_question.SubjectAndQuestionResponseDto;
import uz.sinov.payload.response.subject.SubjectResponseDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;
import uz.sinov.payload.response.test_session.TestCriteriaResponseDto;
import uz.sinov.payload.response.test_session.TestCountsResponseDto;
import uz.sinov.payload.response.test_session.TestSessionResponseDto;
import uz.sinov.payload.response.test_session.TestSessionStartResponseDto;
import uz.sinov.repository.SolveQuestionRepository;
import uz.sinov.repository.StudentTaskRepository;
import uz.sinov.repository.TestSessionRepository;
import uz.sinov.service.TarifService;
import uz.sinov.service.UserSubscriptionService;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
public class TestSessionService {
    private final SessionUser sessionUser;
    private final SubjectService subjectService;
    private final UserSubscriptionService userSubscriptionService;
    private final TarifService tarifService;
    private final TestSessionRepository testSessionRepository;
    private final SolveQuestionService solveQuestionService;
    private final SolveQuestionRepository solveQuestionRepository;
    private final QuestionService questionService;
    private final TestHistoryService testHistoryService;
    private final TaskService taskService;
    private final TestCriteriaService testCriteriaService;
    private final StudentTaskRepository studentTaskRepository;
    private final AnswerService answerService;

    public TestSessionService(SessionUser sessionUser, SubjectService subjectService,
                              UserSubscriptionService userSubscriptionService,
                              TarifService tarifService, TestSessionRepository testSessionRepository,
                              SolveQuestionService solveQuestionService, SolveQuestionRepository solveQuestionRepository,
                              QuestionService questionService, @Lazy TestHistoryService testHistoryService,
                              @Lazy TaskService taskService, TestCriteriaService testCriteriaService,
                              StudentTaskRepository studentTaskRepository, AnswerService answerService) {
        this.sessionUser = sessionUser;
        this.subjectService = subjectService;
        this.userSubscriptionService = userSubscriptionService;
        this.tarifService = tarifService;
        this.testSessionRepository = testSessionRepository;
        this.solveQuestionService = solveQuestionService;
        this.solveQuestionRepository = solveQuestionRepository;
        this.questionService = questionService;
        this.testHistoryService = testHistoryService;
        this.taskService = taskService;
        this.testCriteriaService = testCriteriaService;
        this.studentTaskRepository = studentTaskRepository;
        this.answerService = answerService;
    }

    public TestSessionResponseDto createTestSession(TestSessionCreateOrUpdateRequestDto request) {
        String userId = sessionUser.id();
        this.checkCanStartTest(userId);

        List<TestCriteriaCreateRequestDto> requestCriteria = request.getCriteria();
        if (requestCriteria.isEmpty()) {
            throw new RuntimeException("Test Criteria can not be empty");
        }
        List<TestCriteria> criteriaList = testCriteriaService.mapToTestCriteria(requestCriteria);

        return this.createTestSessionAndSave(request, criteriaList, userId);
    }

    public TestSessionResponseDto createTestSessionAndSave(TestSessionCreateOrUpdateRequestDto request,
                                                           List<TestCriteria> criteriaList,
                                                           String userId) {
        long totalTime = 0;
        int levelCnt = 1;
        int questionCount = 0;
        for (TestCriteria cr : criteriaList) {
            questionCount += cr.getQuestionCount();
            List<QuestionLevel> questionLevel = cr.getQuestionLevel();
            for (QuestionLevel ql : questionLevel) {
                levelCnt++;
                totalTime += ql.getTimeInSeconds();
            }
        }
        totalTime = (totalTime / levelCnt) * questionCount;


        TestSession testSession = TestSession.builder()
                .userId(userId)
                .criteria(criteriaList)
                .duration(totalTime)
                .status(TestSessionStatus.CREATED)
                .build();
        criteriaList.forEach(cr -> cr.setTestSession(testSession));

        testSessionRepository.save(testSession);

        return this.mapToResponseTestSession(testSession);
    }

    public TestSessionResponseDto mapToResponseTestSession(@NonNull TestSession testSession) {
        long remains = 0;
        if (Objects.nonNull(testSession.getFinishedAt())) {
            remains = testSession.getFinishedAt().isAfter(LocalDateTime.now())
                    ?
                    Duration.between(LocalDateTime.now(), testSession.getFinishedAt()).getSeconds()
                    :
                    0L;
        } else if (Objects.nonNull(testSession.getStartedAt())) {
            LocalDateTime dateTime = testSession.getStartedAt().plusSeconds(testSession.getDuration());
            remains = dateTime.isAfter(LocalDateTime.now())
                    ?
                    Duration.between(LocalDateTime.now(), dateTime).getSeconds()
                    :
                    0L;
        }
        List<TestCriteriaResponseDto> testCriteriaResponseDtoList = testCriteriaService.mapToResponseTestCriteria(testSession.getCriteria());

        return TestSessionResponseDto.builder()
                .id(testSession.getId())
                .userId(testSession.getUserId())
                .startedAt(testSession.getStartedAt())
                .finishedAt(testSession.getFinishedAt())
                .duration(testSession.getDuration())
                .remains(remains)
                .criteria(testCriteriaResponseDtoList)
                .status(testSession.getStatus())
                .build();
    }

    private void checkCanStartTest(String userId) {
        UserSubscription userSubscription = userSubscriptionService.checkUserSubscription(userId);
        String tarifId = userSubscription.getTarifId();
        TarifResponseDto tarifResponseById = tarifService.findTarifResponseById(tarifId);
        if (tarifResponseById.getType().equals(TarifType.ORGANIZATIONAL)) {
            return;
        }
        long testCount = testSessionRepository.countByUserId(userId);
        TarifConstraintResponseDto constraint = tarifResponseById.getConstraint();
        if (testCount >= constraint.getMaxTestCount()) {
            throw new RuntimeException("You have reached the limit of tests");
        }
    }

    public TestSessionStartResponseDto startTestSession(TestSessionIdRequestDto request) {
        String testSessionId = request.getTestSessionId();
        String userId = sessionUser.id();

        TestSession testSession = this.findByUserIdAnTestSessionId(userId, testSessionId);
        LocalDateTime now = LocalDateTime.now();

        if (Objects.equals(testSession.getStatus(), TestSessionStatus.FINISHED)) {
            throw new RuntimeException("Test session is finished");
        }

        if (Objects.equals(testSession.getStatus(), TestSessionStatus.STARTED) &&
                testSession.getFinishedAt().isBefore(now)) {
            this.finish(new TestSessionIdRequestDto(testSessionId));
            throw new RuntimeException("Test session time is over");
        }

        if (Objects.equals(testSession.getStatus(), TestSessionStatus.CREATED)) {
            solveQuestionService.create(testSession);
            testSession.setStatus(TestSessionStatus.STARTED);
            testSession.setStartedAt(now);
        }
        List<TestCriteria> criteria = testSession.getCriteria();


        long totalTime = 0;
        List<SolveQuestionResponseDto> solveQuestionResponseDtoList = new ArrayList<>();
        List<SubjectResponseDto> subjectResponseDtoList = new ArrayList<>();
        for (TestCriteria cr : criteria) {
            Subject subject = cr.getSubject();
            List<SolveQuestion> solveQuestions = solveQuestionRepository.findBySubjectIdAnTestSessionId(subject.getId(), testSessionId);

            for (SolveQuestion solveQuestion : solveQuestions) {
                QuestionResponseDto questionResponseDto = questionService.findResponseById(solveQuestion.getQuestionId());
                solveQuestionResponseDtoList.add(SolveQuestionResponseDto.builder()
                        .userAnswerId(solveQuestion.getUserAnswerId())
                        .testSessionId(solveQuestion.getTestSession().getId())
                        .question(questionResponseDto)
                        .id(solveQuestion.getId())
                        .build());
                totalTime += questionResponseDto.getQuestionLevel().getTimeInSeconds();
            }

            subjectResponseDtoList.add(subjectService.mapToResponse(subject));

        }
        var subjectAndQuestionResponseDto = new SubjectAndQuestionResponseDto(subjectResponseDtoList, solveQuestionResponseDtoList);

        testSession.setDuration(totalTime);
        testSession.setFinishedAt(testSession.getStartedAt().plusSeconds(totalTime));
        testSessionRepository.save(testSession);

        return new TestSessionStartResponseDto(this.mapToResponseTestSession(testSession), subjectAndQuestionResponseDto);
    }

    public TestSession findByUserIdAnTestSessionId(String userId, String testSessionId) {
        return testSessionRepository.findByUserIdAndId(userId, testSessionId)
                .orElseThrow(() -> new RuntimeException("Test session not found with id '%s'".formatted(testSessionId)));
    }

    public TestCountsResponseDto finish(TestSessionIdRequestDto request) {
        String testSessionId = request.getTestSessionId();
        String userId = sessionUser.id();
        TestSession testSession = this.findByUserIdAnTestSessionId(userId, testSessionId);

        if (Objects.equals(testSession.getStatus(), TestSessionStatus.FINISHED)) {
            throw new RuntimeException("Test session already finished");
        }

        TestCountsResponseDto testCountsResponseDto = this.calculateTestSessionResult(testSession);
        if (testSession.getFinishedAt().isBefore(LocalDateTime.now())) {
            testSession.setStatus(TestSessionStatus.FINISHED);
            testSession.setFinishedAt(testSession.getStartedAt().plusSeconds(testSession.getDuration()));
            testSessionRepository.save(testSession);

            testHistoryService.generateHistory(testSession, testCountsResponseDto);
            taskService.finish(request);
            return testCountsResponseDto;
        }
        testSession.setStatus(TestSessionStatus.FINISHED);
        testSession.setFinishedAt(LocalDateTime.now());
        testSessionRepository.save(testSession);

        testHistoryService.generateHistory(testSession, testCountsResponseDto);

        taskService.finish(request);


        return testCountsResponseDto;
    }

    public TestCountsResponseDto calculateTestSessionResult(TestSession testSession) {
        List<SolveQuestion> solveQuestions = solveQuestionRepository.findAllByTestSessionId(testSession.getId());
        int correctCount = 0;
        int wrongCount = 0;
        int emptyCount = 0;
        for (SolveQuestion solveQuestion : solveQuestions) {
            if (Objects.isNull(solveQuestion.getUserAnswerId())) {
                emptyCount++;
            } else {
                Answer correctAnswerByQuestionId = answerService.findCorrectByQuestionId(solveQuestion.getQuestionId());
                if (Objects.equals(solveQuestion.getUserAnswerId(), correctAnswerByQuestionId.getId())) {
                    correctCount++;
                } else {
                    wrongCount++;
                }
            }
        }
        return TestCountsResponseDto.builder()
                .totalQuestionCount(solveQuestions.size())
                .correctAnswerCount(correctCount)
                .wrongAnswerCount(wrongCount)
                .emptyAnswerCount(emptyCount)
                .build();
    }

    public List<TestSessionResponseDto> getAllActiveTestSessions() {
        String userId = sessionUser.id();
        List<TestSession> testSessions = testSessionRepository.findByUserIdAndActive(userId);
        return this.mapToResponseTestSession(testSessions);
    }

    public List<TestSessionResponseDto> mapToResponseTestSession(List<TestSession> testSessions) {
        return testSessions.stream()
                .map(this::mapToResponseTestSession)
                .collect(Collectors.toList());
    }

    @Async
    public void findAndFinish() {
        try {
            List<TestSession> testSessions = testSessionRepository.findUnfinished();
            for (TestSession testSession : testSessions) {
                testSession.setStatus(TestSessionStatus.FINISHED);
                testSession.setFinishedAt(LocalDateTime.now());
                testSessionRepository.save(testSession);

                testHistoryService.generateHistory(testSession,this.calculateTestSessionResult(testSession));

                Optional<StudentTask> studentTaskOptional = studentTaskRepository.findByTestSessionId(testSession.getId());
                if (studentTaskOptional.isPresent()) {
                    StudentTask studentTask = studentTaskOptional.get();
                    studentTask.setStatus(StudentTaskStatus.FINISHED);
                    studentTaskRepository.save(studentTask);
                }
            }
        } catch (Exception exception) {
            log.error("Error while updating test session status", exception);
        }
    }
}
