package uz.sinov.mappers;


import lombok.RequiredArgsConstructor;
import org.mapstruct.Mapper;
import uz.sinov.entity.Organization;
import uz.sinov.entity.Tarif;
import uz.sinov.payload.request.tarif.TarifCreateRequestDto;
import uz.sinov.payload.response.auth.UserResponseDto;
import uz.sinov.payload.response.organization.AddressResponseDto;
import uz.sinov.payload.response.organization.OrganizationResponseDto;

@RequiredArgsConstructor
@Mapper(componentModel = "spring")
public abstract class OrganizationMapper {
    public OrganizationResponseDto mapToOrganizationResponseDto(Organization organization,
                                                                AddressResponseDto addressResponseDto,
                                                                UserResponseDto userResponseDto) {
        return OrganizationResponseDto.builder()
                .id(organization.getId())
                .name(organization.getName())
                .description(organization.getDescription())
                .address(addressResponseDto)
                .director(userResponseDto)
                .status(organization.getStatus())
                .build();
    }

    public abstract Tarif mapToTarif(TarifCreateRequestDto dto);
}
