package uz.sinov.mappers;


import org.mapstruct.Mapper;
import uz.sinov.entity.AuthUser;
import uz.sinov.payload.response.auth.UserResponseDto;

@Mapper(componentModel = "spring")
public abstract class UserMapper {
    public abstract UserResponseDto mapToDirectorResponse(AuthUser authUser);
}
