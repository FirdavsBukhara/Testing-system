package uz.sinov.mappers;


import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import uz.sinov.entity.TarifConstraint;
import uz.sinov.payload.request.tarif.TarifConstraintCreateRequestDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;

import java.util.List;

@Mapper(componentModel = "spring")
public abstract class TarifConstraintMapper {

    public abstract TarifConstraintResponseDto mapToConstraintResponseDto(TarifConstraint tarifConstraint);

    @Mapping(target = "tarifId", source = "tarifId")
    public abstract TarifConstraint mapToTarifConstraint(String tarifId, TarifConstraintCreateRequestDto dto);

    public abstract List<TarifConstraintResponseDto> mapToTarifResponseDtoList(List<TarifConstraint> tarifConstraints);
}
