package uz.sinov.mappers;


import org.mapstruct.Mapper;
import uz.sinov.entity.UserSubscription;
import uz.sinov.payload.response.user_subscribe.UserSubscriptionResponseDto;

import java.util.List;

@Mapper(componentModel = "spring")
public abstract class UserSubscriptionMapper {
    public abstract UserSubscriptionResponseDto mapToDto(UserSubscription userSubscription);

    public abstract List<UserSubscriptionResponseDto> mapToDto(List<UserSubscription> userSubscriptions);
}
