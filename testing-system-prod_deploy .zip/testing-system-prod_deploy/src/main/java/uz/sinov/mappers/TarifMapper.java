package uz.sinov.mappers;


import lombok.RequiredArgsConstructor;
import org.mapstruct.Mapper;
import uz.sinov.entity.Tarif;
import uz.sinov.payload.request.tarif.TarifCreateRequestDto;
import uz.sinov.payload.response.tarif.TarifConstraintResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;

@RequiredArgsConstructor
@Mapper(componentModel = "spring")
public abstract class TarifMapper {
    public TarifResponseDto mapToTarifResponseDto(Tarif tarif, TarifConstraintResponseDto tarifConstraintResponseDto) {
        return TarifResponseDto.builder()
                .id(tarif.getId())
                .name(tarif.getName())
                .fromTime(tarif.getFromTime())
                .toTime(tarif.getToTime())
                .description(tarif.getDescription())
                .price(tarif.getPrice())
                .type(tarif.getType())
                .status(tarif.getStatus())
                .constraint(tarifConstraintResponseDto)
                .build();
    }

    public abstract Tarif mapToTarif(TarifCreateRequestDto dto);
}
