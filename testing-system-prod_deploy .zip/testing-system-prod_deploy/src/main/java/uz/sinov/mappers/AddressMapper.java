package uz.sinov.mappers;


import org.mapstruct.Mapper;
import uz.sinov.entity.Address;
import uz.sinov.payload.request.organization.AddressCreateRequestDto;
import uz.sinov.payload.response.organization.AddressResponseDto;

@Mapper(componentModel = "spring")
public abstract class AddressMapper {
    public abstract Address mapToAddress(AddressCreateRequestDto addressCreateRequestDto);

    public abstract AddressResponseDto mapToResponseAddress(Address address);
}
