package uz.sinov.enums;

public enum GroupTeacherSpecialization {
    GENERAL,
    MATHEMATICS,
    PHYSICS,
    CHEMISTRY,
    BIOLOGY,
    ENGLISH,
    RUSSIAN,
    UZBEK,
    HISTORY,
    GEOGRAPHY,
    SPORT,
    ART,
    MUSIC,
}
