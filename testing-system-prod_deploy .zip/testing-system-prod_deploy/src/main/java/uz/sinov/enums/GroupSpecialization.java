package uz.sinov.enums;

public enum GroupSpecialization {
    GENERAL,
    IT,
    MATH,
    PHYSICS,
    CHEMISTRY,
    BIOLOGY,
    ENGLISH,
    RUSSIAN,
    UZBEK,
    HISTORY,
    GEOGRAPHY,
    SPORT,
    ART,
    MUSIC,
    DANCE,
    DRAMA,
    PSYCHOLOGY,
    PHILOSOPHY,
    SOCIOLOGY,
    ECONOMICS,
    LAW,
    BUSINESS,
    MARKETING;
}
