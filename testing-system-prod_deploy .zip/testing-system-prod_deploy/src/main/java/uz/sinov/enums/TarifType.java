package uz.sinov.enums;

public enum TarifType {
    FREE,
    ORGANIZATIONAL,
    PERSONAL;

    public static TarifType getByName(String type) {
        for (TarifType value : values()) {
            if (value.name().equalsIgnoreCase(type)) {
                return value;
            }
        }
        return null;
    }
}
