package uz.sinov.enums;

public enum UserStatus {
    NO_ACTIVE,
    ACTIVE,
    BLOCKED,
    DELETED;
}
