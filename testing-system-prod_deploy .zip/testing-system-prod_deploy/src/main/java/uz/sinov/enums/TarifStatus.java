package uz.sinov.enums;

public enum TarifStatus {
    NO_ACTIVE,
    ACTIVE,
    ARCHIVED,
    DELETED;
}
