package uz.sinov.enums;

public enum GroupStudentStatus {
    IN,
    NOT_IN;
}
