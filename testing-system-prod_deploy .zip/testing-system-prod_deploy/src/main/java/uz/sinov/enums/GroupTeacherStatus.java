package uz.sinov.enums;

public enum GroupTeacherStatus {
    IN,
    NOT_IN;
}
