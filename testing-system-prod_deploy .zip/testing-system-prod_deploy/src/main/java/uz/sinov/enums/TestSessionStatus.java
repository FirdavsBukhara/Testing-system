package uz.sinov.enums;

public enum TestSessionStatus {
    CREATED,
    STARTED,
    FINISHED
}
