package uz.sinov.enums;

public enum OrganizationDirectorStatus {
    ACTIVE,
    NO_ACTIVE;
}
