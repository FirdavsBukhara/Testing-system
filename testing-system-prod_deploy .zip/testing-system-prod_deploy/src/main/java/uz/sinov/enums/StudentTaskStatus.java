package uz.sinov.enums;

public enum StudentTaskStatus {
    CREATED,
    STARTED,
    FINISHED
}
