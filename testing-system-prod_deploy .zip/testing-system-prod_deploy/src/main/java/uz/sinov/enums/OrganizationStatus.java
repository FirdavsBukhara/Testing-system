package uz.sinov.enums;

public enum OrganizationStatus {
    OPEN,
    CLOSED,
    DELETED
}
