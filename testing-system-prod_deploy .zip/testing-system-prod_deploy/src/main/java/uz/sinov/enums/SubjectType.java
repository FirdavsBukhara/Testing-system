package uz.sinov.enums;

public enum SubjectType {
    GLOBAL, PRIVATE
}
