package uz.sinov.enums;

public enum TokenType {
    ACCESS, REFRESH
}
