package uz.sinov.enums;

public enum SMSCodeType {
    ACTIVATION,
    FORGET_PASSWORD,
    DELETE_ACCOUNT
}
