package uz.sinov.enums;

public enum UserSubscriptionStatus {
    NO_ACTIVE,
    ACTIVE,
    EXPIRED;
}
