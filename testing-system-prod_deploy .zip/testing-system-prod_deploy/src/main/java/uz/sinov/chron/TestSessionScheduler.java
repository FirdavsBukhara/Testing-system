package uz.sinov.chron;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import uz.sinov.service.testing.TestSessionService;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@RequiredArgsConstructor
public class TestSessionScheduler {

    private final TestSessionService testSessionService;

    @Scheduled(fixedDelay = 30, initialDelay = 10, timeUnit = TimeUnit.SECONDS)
    public void finishUnfinishedTestSessions() {
        log.info("Finishing unfinished test sessions");
        CompletableFuture.runAsync(testSessionService::findAndFinish);
    }
}
