package uz.sinov.payload.request.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record UserActivateRequestDto(String phoneNumber, String code) {
}
