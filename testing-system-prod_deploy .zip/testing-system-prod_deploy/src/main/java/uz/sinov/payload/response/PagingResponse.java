package uz.sinov.payload.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import uz.sinov.payload.request.PagingRequest;

import java.util.Objects;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class PagingResponse {
    private Integer currentPage;
    private Integer totalPages;
    private Long totalItems;

    public static PagingResponse of(PagingRequest reqPaging, Long totalItems) {
        PagingResponse paging = new PagingResponse();
        paging.setCurrentPage(Objects.nonNull(reqPaging) ? reqPaging.getPage() : 0);
        paging.setTotalItems(totalItems);
        paging.setTotalPages(Objects.nonNull(reqPaging) ? ((int) Math.ceil(totalItems.doubleValue() / reqPaging.getSize())) : 0);
        return paging;
    }

    public PagingResponse(Integer currentPage, Integer totalPages, Long totalItems) {
        this.currentPage = currentPage;
        this.totalPages = totalPages;
        this.totalItems = totalItems;
    }
}
