package uz.sinov.payload.request.pdf;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PdfParagraphDto {
    private String fullName;
    private String phoneNumber;
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;
    private float totalScore;
}
