package uz.sinov.payload.response.test_session;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.solve_question.SubjectAndQuestionResponseDto;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TestSessionStartResponseDto implements Serializable {
    private TestSessionResponseDto testSession;
    private SubjectAndQuestionResponseDto subjectsAndQuestions;
}
