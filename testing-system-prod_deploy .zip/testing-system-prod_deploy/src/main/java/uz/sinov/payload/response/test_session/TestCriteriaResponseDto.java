package uz.sinov.payload.response.test_session;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.question_level.QuestionLevelResponseDto;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TestCriteriaResponseDto implements Serializable {
    private Integer id;

    private Integer subjectId;

    private List<QuestionLevelResponseDto> questionLevels;

    private Integer questionCount;
}
