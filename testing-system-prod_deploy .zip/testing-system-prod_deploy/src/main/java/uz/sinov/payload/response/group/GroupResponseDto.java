package uz.sinov.payload.response.group;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.GroupSpecialization;
import uz.sinov.payload.response.organization.OrganizationResponseDto;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupResponseDto {
    private String id;

    private OrganizationResponseDto organization;

    private String name;

    private String description;

    private GroupSpecialization specialization;
}
