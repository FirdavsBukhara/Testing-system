package uz.sinov.payload.request.task;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import uz.sinov.payload.request.test_session.TestCriteriaCreateRequestDto;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaskCreateRequestDto {
    private String groupId;

    private String name;

    private String description;

    private LocalDateTime deadline;

    private TestCriteriaCreateRequestDto criteria;
}
