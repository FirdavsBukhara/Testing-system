package uz.sinov.payload.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseDto<T> {
    private String message;
    private T data;
    private AppErrorDto error;
    private boolean success;

    public ResponseDto(T data) {
        this(null, data, true);
    }

    public ResponseDto(AppErrorDto dto) {
        this(dto, false);
    }

    public ResponseDto(T data, String message) {
        this(message, data, true);
    }

    private ResponseDto(String message, T data, boolean success) {
        this.message = message;
        this.data = data;
        this.success = success;
    }

    private ResponseDto(AppErrorDto error, boolean success) {
        this.error = error;
        this.success = success;
    }
}
