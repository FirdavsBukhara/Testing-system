package uz.sinov.payload.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PagingRequest {

    @Schema(description = "Sahifani raqami", example = "0")
    private Integer page = 0;

    @Schema(description = "Sahifadagi elementlar soni", example = "10")
    private Integer size = 10;

    public Integer getSize() {
        if (this.size < 5) {
            return 5;
        }
        if (this.size > 100) {
            return 100;
        }
        return this.size;
    }

    public Integer getPage() {
        if (this.page < 0) {
            return 0;
        }
        return this.page;
    }
}
