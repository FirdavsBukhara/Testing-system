package uz.sinov.payload.response.organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.OrganizationStatus;
import uz.sinov.payload.response.auth.UserResponseDto;

import java.io.Serializable;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationResponseDto implements Serializable {
    private String id;

    private String name;

    private AddressResponseDto address;

    private String description;

    private OrganizationStatus status;

    private UserResponseDto director;
}
