package uz.sinov.payload.response.test_history;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.test_session.TestCountsResponseDto;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestHistoryResponseDto implements Serializable {
    private Integer id;

    private String userId;

    private String testSessionId;

    private LocalDateTime startedAt;

    private LocalDateTime finishedAt;

    private float totalScore;

    private String documentId;

    private Integer totalQuestionCount;

    private Integer correctAnswerCount;

    private Integer wrongAnswerCount;

    private Integer emptyAnswerCount;
}
