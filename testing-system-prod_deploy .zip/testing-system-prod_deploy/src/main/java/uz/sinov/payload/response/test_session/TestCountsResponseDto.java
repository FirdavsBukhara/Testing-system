package uz.sinov.payload.response.test_session;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TestCountsResponseDto implements Serializable {
    private Integer totalQuestionCount;
    private Integer correctAnswerCount;
    private Integer wrongAnswerCount;
    private Integer emptyAnswerCount;
}
