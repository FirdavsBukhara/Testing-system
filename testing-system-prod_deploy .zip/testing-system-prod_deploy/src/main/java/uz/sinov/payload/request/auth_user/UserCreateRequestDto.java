package uz.sinov.payload.request.auth_user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public final class UserCreateRequestDto implements Serializable {
    @NotBlank(message = "Name can not be blank")
    private String name;

    @Pattern(regexp = "^(998)(\\d{9})", message = "Phone number must be in format 998xxxxxxxxx")
    @NotBlank(message = "Phone number can not be blank")
    private String phoneNumber;

    @NotBlank(message = "Password can not be blank")
    private String password;

    @NotBlank(message = "Confirm Password can not be blank")
    private String confirmPassword;
}
