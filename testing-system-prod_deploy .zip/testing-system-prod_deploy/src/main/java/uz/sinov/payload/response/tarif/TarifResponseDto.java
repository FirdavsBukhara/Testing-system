package uz.sinov.payload.response.tarif;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.TarifStatus;
import uz.sinov.enums.TarifType;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TarifResponseDto {
    private String id;

    private String name;

    private Double price;

    private LocalDate fromTime;

    private LocalDate toTime;

    private String description;

    private TarifType type;

    private TarifStatus status;

    private TarifConstraintResponseDto constraint;
}
