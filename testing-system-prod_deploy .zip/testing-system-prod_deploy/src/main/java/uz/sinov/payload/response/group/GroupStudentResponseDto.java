package uz.sinov.payload.response.group;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.GroupStudentStatus;
import uz.sinov.payload.response.auth.UserResponseDto;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupStudentResponseDto {
    private String id;

    private String groupId;

    private UserResponseDto student;

    private GroupStudentStatus status;
}
