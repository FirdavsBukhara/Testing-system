package uz.sinov.payload.request.question_level;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuestionLevelCreateRequestDto {
    @NotBlank(message = "Question level name is required")
    private String name;

    private String description;

    @Min(value = 1, message = "Level should be at least {value}")
    private Integer level;

    @Min(value = 0, message = "Score should be at least {value}")
    private Float score;

    @Min(value = 1, message = "Time should be at least {value} sec")
    private Integer timeInSeconds;

    private String textColor;
}
