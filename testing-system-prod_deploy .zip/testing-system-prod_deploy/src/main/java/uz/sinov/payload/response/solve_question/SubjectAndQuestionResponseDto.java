package uz.sinov.payload.response.solve_question;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.subject.SubjectResponseDto;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SubjectAndQuestionResponseDto implements Serializable {
    private List<SubjectResponseDto> subjects;
    private List<SolveQuestionResponseDto> solveQuestions;
}
