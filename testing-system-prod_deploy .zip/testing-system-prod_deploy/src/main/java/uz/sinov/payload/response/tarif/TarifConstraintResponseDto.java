package uz.sinov.payload.response.tarif;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TarifConstraintResponseDto {
    private String id;

    private String tarifId;

    private Integer periodInDays;

    private Short maxGroupCount;

    private Short maxOrganizationCount;

    private Short maxTestCount;

    private Short maxBuyCount;
}
