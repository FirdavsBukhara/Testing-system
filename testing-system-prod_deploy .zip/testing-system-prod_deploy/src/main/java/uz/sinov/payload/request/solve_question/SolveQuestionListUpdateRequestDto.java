package uz.sinov.payload.request.solve_question;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SolveQuestionListUpdateRequestDto {
    private String testSessionId;
    private List<SolveQuestionUpdateRequestDto> questions;
}
