package uz.sinov.payload.request.question;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.request.PagingRequest;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QuestionPageRequestDto {
    private PagingRequest paging = new PagingRequest();
    private Integer subjectId;
}
