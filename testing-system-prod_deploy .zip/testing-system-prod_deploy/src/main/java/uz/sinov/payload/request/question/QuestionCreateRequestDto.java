package uz.sinov.payload.request.question;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.request.answers.AnswerCreateRequestDto;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QuestionCreateRequestDto {

    @Schema(description = "Qaysi fan ekanligi", example = "0")
    private Integer subjectId;

    @Schema(description = "Rasm id , agar rasm bo'lsa", example = "22a9df44-d46d-4fad-9858-34ab86b00012.png")
    private String imgId;

    @Schema(description = "Savol matni", example = "2 * 2 = ?")
    private String text;

    @Schema(description = "Savol qiyinlik darajasi", example = "0")
    private Integer questionLevelId;

    @Schema(description = "Javoblar", example = "[{\"text\":\"4\",\"correct\":true},{\"text\":\"5\",\"correct\":false}]")
    private List<AnswerCreateRequestDto> answers;
}
