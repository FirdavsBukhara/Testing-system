package uz.sinov.payload.response.organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddressResponseDto {
    private Integer id;

    private String region;

    private String district;

    private String street;

    private String home;

    private String lon;

    private String lat;
}
