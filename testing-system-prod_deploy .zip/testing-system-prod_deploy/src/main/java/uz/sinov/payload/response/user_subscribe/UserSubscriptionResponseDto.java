package uz.sinov.payload.response.user_subscribe;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.UserSubscriptionStatus;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserSubscriptionResponseDto {
    private String id;

    private String userId;

    private String tarifId;

    private LocalDate fromTime;

    private LocalDate toTime;

    private UserSubscriptionStatus status;
}
