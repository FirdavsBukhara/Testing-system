package uz.sinov.payload.response.question;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.answers.AnswerResponseDto;
import uz.sinov.payload.response.question_level.QuestionLevelResponseDto;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuestionResponseDto implements Serializable {
    private String id;

    private Integer subjectId;

    private String imgId;

    private String text;

    private QuestionLevelResponseDto questionLevel;

    private List<AnswerResponseDto> answers;
}
