package uz.sinov.payload.request.test_session;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TestCriteriaCreateRequestDto {
    private Integer subjectId;

    private List<Integer> questionLevels;

    @Min(value = 1, message = "Question count must be greater than 0")
    private Integer questionCount;
}
