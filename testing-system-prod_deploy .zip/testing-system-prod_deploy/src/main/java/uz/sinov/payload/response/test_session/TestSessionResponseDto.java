package uz.sinov.payload.response.test_session;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.TestSessionStatus;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TestSessionResponseDto implements Serializable {
    private String id;

    private String userId;

    private LocalDateTime startedAt;

    private LocalDateTime finishedAt;

    private Long duration;

    private Long remains;

    private List<TestCriteriaResponseDto> criteria;

    private TestSessionStatus status;
}
