package uz.sinov.payload.request.pdf;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PdfSubjectDto {
    private String subjectName;
    private List<PdfOneQuestionDto> questionList;
}
