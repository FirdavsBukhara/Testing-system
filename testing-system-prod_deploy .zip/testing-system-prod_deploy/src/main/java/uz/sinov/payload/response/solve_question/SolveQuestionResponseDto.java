package uz.sinov.payload.response.solve_question;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.question.QuestionResponseDto;

import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SolveQuestionResponseDto implements Serializable {
    private String id;

    private String testSessionId;

    private QuestionResponseDto question;

    private String userAnswerId;
}
