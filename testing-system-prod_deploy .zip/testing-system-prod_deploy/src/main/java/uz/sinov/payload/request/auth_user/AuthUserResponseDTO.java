package uz.sinov.payload.request.auth_user;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.UserStatus;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthUserResponseDTO {
    private String id;

    private String name;

    private String phoneNumber;

    private String profileImg;

    private RoleResponseDto role;

    private UserStatus status;

    private Double balance;
}
