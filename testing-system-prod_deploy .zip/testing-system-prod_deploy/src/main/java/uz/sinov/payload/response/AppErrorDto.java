package uz.sinov.payload.response;

import lombok.Getter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
public class AppErrorDto implements Serializable {
    private final String errorPath;
    private final String errorMessage;
    private final Integer errorCode;
    private final Object errorBody;
    private final LocalDateTime time;


    public AppErrorDto(String errorPath, String errorMessage, Integer errorCode) {
        this(errorPath, errorMessage, null, errorCode);
    }

    public AppErrorDto(String errorPath, String errorMessage, Object errorBody, Integer errorCode) {
        this.errorPath = errorPath;
        this.errorMessage = errorMessage;
        this.errorBody = errorBody;
        this.errorCode = errorCode;
        this.time = LocalDateTime.now();
    }
}

