package uz.sinov.payload.response.task;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.payload.response.test_session.TestCriteriaResponseDto;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TaskResponseDto {
    private String id;

    private String groupId;

    private String name;

    private String description;

    private LocalDateTime deadline;

    private TestCriteriaResponseDto criteria;
}
