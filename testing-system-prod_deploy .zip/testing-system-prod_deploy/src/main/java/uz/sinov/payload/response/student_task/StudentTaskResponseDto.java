package uz.sinov.payload.response.student_task;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.StudentTaskStatus;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StudentTaskResponseDto {
    private String id;

    private String groupId;

    private String studentId;

    private String testSessionId;

    private String taskId;

    private StudentTaskStatus status;
}
