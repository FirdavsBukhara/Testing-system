package uz.sinov.payload.request.auth_user;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserUpdateDTO {
    private String id;

    @NotBlank(message = "Username can't be blank")
    private String username;

    @NotBlank(message = "Firstname can't be blank")
    private String firstName;

    @NotBlank(message = "Lastname can't be blank")
    private String lastName;

    private String password;

    private List<String> permissions;

    private Integer state;

    private String profileImgId;

    @NotBlank(message = "Email can't be blank")
    private String email;
}