package uz.sinov.payload.request.tarif;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.TarifType;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TarifCreateRequestDto {
    @NotBlank
    private String name;

    @Min(value = 0)
    private Double price;

    private LocalDate fromTime;

    private LocalDate toTime;

    private String description;

    private TarifType type = TarifType.FREE;

    private TarifConstraintCreateRequestDto constraint;
}
