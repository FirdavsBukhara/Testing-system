package uz.sinov.payload.request.auth;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;

@JsonIgnoreProperties(ignoreUnknown = true)
public record TokenRequestDto(@NotBlank String phoneNumber, @NotBlank String password) {
}
