package uz.sinov.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class BaseUtils {

    public String getExtension(String fileName) {
        return fileName.substring(fileName.lastIndexOf("."));
    }

}
