package uz.sinov.config.handlers;

import io.jsonwebtoken.ExpiredJwtException;
import jakarta.persistence.EntityNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import uz.sinov.payload.response.AppErrorDto;
import uz.sinov.payload.response.ResponseDto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public ResponseDto<Void> handleUnknownExceptions(Exception e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 500);
        log.error("Exception path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler({RuntimeException.class})
    public ResponseDto<Void> handleRuntimeExceptions(RuntimeException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 400);
        log.error("RuntimeException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler({ExpiredJwtException.class})
    public ResponseDto<Void> handleExpiredJwtExceptions(ExpiredJwtException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 401);
        log.error("ExpiredJwtException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }


    @ExceptionHandler(AccessDeniedException.class)
    public ResponseDto<Void> handleAccessDeniedException(AccessDeniedException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 403);
        log.error("AccessDeniedException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler(DisabledException.class)
    public ResponseDto<Void> handleDisabledException(DisabledException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 403);
        log.error("DisabledException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler(CredentialsExpiredException.class)
    public ResponseDto<Void> handleCredentialsExpiredException(CredentialsExpiredException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 401);
        log.error("CredentialsExpiredException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler({InsufficientAuthenticationException.class})
    public ResponseDto<Void> handleInsufficientAuthenticationException(InsufficientAuthenticationException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 401);
        log.error("InsufficientAuthenticationException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler({EntityNotFoundException.class})
    public ResponseDto<Void> handleEntityNotFoundException(EntityNotFoundException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 400);
        log.error("EntityNotFoundException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler({IllegalArgumentException.class})
    public ResponseDto<Void> handleIllegalArgumentException(IllegalArgumentException e, HttpServletRequest request) {
        AppErrorDto error = new AppErrorDto(request.getRequestURI(), e.getMessage(), 400);
        log.error("IllegalArgumentException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseDto<Void> handleMethodArgumentNotValidException(MethodArgumentNotValidException e, HttpServletRequest request) {
        String errorMessage = "Input is not valid";
        Map<String, List<String>> errorBody = getErrorBody(e);
        String errorPath = request.getRequestURI();
        AppErrorDto error = new AppErrorDto(errorPath, errorMessage, errorBody, 400);
        log.error("MethodArgumentNotValidException path: '{}', message: '{}'", error.getErrorPath(), error.getErrorMessage(), e);
        return new ResponseDto<>(error);
    }

    @NotNull
    private static Map<String, List<String>> getErrorBody(MethodArgumentNotValidException e) {
        Map<String, List<String>> errorBody = new HashMap<>();
        for (FieldError fieldError : e.getFieldErrors()) {
            String field = fieldError.getField();
            String message = fieldError.getDefaultMessage();
            errorBody.compute(field, (s, values) -> {
                if (!Objects.isNull(values))
                    values.add(message);
                else
                    values = new ArrayList<>(Collections.singleton(message));
                return values;
            });
        }
        return errorBody;
    }
}
