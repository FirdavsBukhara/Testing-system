package uz.sinov.config.props;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties("file.minio")
public class MinIoProps {
    private String url;
    private String bucket;
    private String accessKey;
    private String secretKey;
}
