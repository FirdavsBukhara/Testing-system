package uz.sinov.config.props;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "jwt")
public class JwtProps {
    private String accessTokenSecretKey;
    private long accessTokenExpiry;
    private String refreshTokenSecretKey;
    private long refreshTokenExpiry;
}
