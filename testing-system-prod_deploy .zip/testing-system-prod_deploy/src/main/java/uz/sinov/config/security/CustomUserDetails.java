package uz.sinov.config.security;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import uz.sinov.entity.AuthUser;
import uz.sinov.entity.Role;
import uz.sinov.enums.UserStatus;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Getter
@RequiredArgsConstructor
public class CustomUserDetails implements UserDetails {
    private final AuthUser authUser;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (Objects.isNull(this.authUser)) {
            return Collections.emptyList();
        }
        Role role = this.authUser.getRole();
        if (Objects.isNull(role) || Objects.isNull(role.getPermissions()) || role.getPermissions().isEmpty()) {
            return Collections.emptyList();
        }
        return role.getPermissions().stream()
                .map(perm -> new SimpleGrantedAuthority(perm.name()))
                .toList();
    }

    @Override
    public String getPassword() {
        return Objects.isNull(this.authUser) ? null : this.authUser.getPassword();
    }

    @Override
    public String getUsername() {
        return Objects.isNull(this.authUser) ? null : this.authUser.getPhoneNumber();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return !UserStatus.BLOCKED.equals(this.authUser.getStatus());
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return UserStatus.ACTIVE.equals(this.authUser.getStatus());
    }
}
