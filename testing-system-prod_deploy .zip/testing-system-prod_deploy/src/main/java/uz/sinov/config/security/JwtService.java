package uz.sinov.config.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uz.sinov.config.props.JwtProps;
import uz.sinov.enums.TokenType;
import uz.sinov.payload.response.auth.TokenResponseDto;

import java.security.Key;
import java.util.Date;

import static uz.sinov.enums.TokenType.ACCESS;
import static uz.sinov.enums.TokenType.REFRESH;


@Slf4j
@Service
@RequiredArgsConstructor
public class JwtService {
    private final JwtProps jwtProps;

    public TokenResponseDto generateToken(String phoneNumber) {
        TokenResponseDto tokenResponseDto = new TokenResponseDto();
        generateAccessToken(phoneNumber, tokenResponseDto);
        generateRefreshToken(phoneNumber, tokenResponseDto);
        return tokenResponseDto;
    }

    public TokenResponseDto generateRefreshToken(String username, TokenResponseDto tokenResponseDto) {
        Date refreshTokenExp = new Date(System.currentTimeMillis() + jwtProps.getRefreshTokenExpiry());
        Date issuedAt = new Date();
        String refreshToken = Jwts.builder()
                .setSubject(username)
                .setIssuedAt(issuedAt)
                .setExpiration(refreshTokenExp)
                .signWith(signKey(REFRESH), SignatureAlgorithm.HS256)
                .compact();
        tokenResponseDto.setRefreshToken(refreshToken);
        return tokenResponseDto;
    }

    public TokenResponseDto generateAccessToken(String username, TokenResponseDto tokenResponseDto) {
        Date accessTokenExp = new Date(System.currentTimeMillis() + jwtProps.getAccessTokenExpiry());
        Date issuedAt = new Date();
        String accessToken = Jwts.builder()
                .setSubject(username)
                .setIssuedAt(issuedAt)
                .setExpiration(accessTokenExp)
                .signWith(this.signKey(ACCESS), SignatureAlgorithm.HS512)
                .compact();
        tokenResponseDto.setAccessToken(accessToken);
        return tokenResponseDto;
    }

    public boolean isTokenValid(String token, TokenType tokenType) {
        try {
            Date expiration = this.getExpiry(token, tokenType);
            return expiration.after(new Date()) && getUsername(token, tokenType) != null;
        } catch (Exception e) {
            log.error("Error in isTokenValid method in JwtService message = '{}'", e.getMessage());
            return false;
        }
    }

    public String getUsername(String token, TokenType tokenType) {
        Claims claims = this.getClaims(token, tokenType);
        return claims.getSubject();
    }

    public Date getExpiry(String token, TokenType tokenType) {
        Claims claims = this.getClaims(token, tokenType);
        return claims.getExpiration();
    }

    private Claims getClaims(String token, TokenType tokenType) {
        return Jwts.parserBuilder()
                .setSigningKey(signKey(tokenType))
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    private Key signKey(TokenType tokenType) {
        byte[] bytes = Decoders.BASE64.decode(
                tokenType.equals(ACCESS)
                        ? jwtProps.getAccessTokenSecretKey()
                        : jwtProps.getRefreshTokenSecretKey()
        );
        return Keys.hmacShaKeyFor(bytes);
    }
}
