package uz.sinov.config.security;

import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import uz.sinov.entity.AuthUser;

import java.util.Objects;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class SessionUser {
    public AuthUser user() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        Authentication authentication = securityContext.getAuthentication();
        if (Objects.isNull(authentication) || authentication instanceof AnonymousAuthenticationToken)
            return null;
        Object principal = authentication.getPrincipal();
        if (principal instanceof CustomUserDetails userDT)
            return userDT.getAuthUser();
        return null;
    }

    public String id() {
        AuthUser user = this.user();
        if (Objects.isNull(user)) {
            return UUID.randomUUID().toString();
        }
        return user.getId();
    }
}
