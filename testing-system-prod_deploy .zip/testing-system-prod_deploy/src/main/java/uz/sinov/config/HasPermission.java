package uz.sinov.config;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uz.sinov.config.security.SessionUser;
import uz.sinov.entity.AuthUser;
import uz.sinov.enums.Permission;

import java.util.List;
import java.util.Objects;


@RequiredArgsConstructor
@Component("HasPermission")
public class HasPermission {
    private final SessionUser sessionUser;

    public boolean hasPermission(Permission permission) {
        return true;
//        AuthUser user = sessionUser.user();
//        if (Objects.isNull(user) || Objects.isNull(user.getRole())) {
//            return false;
//        }
//        if ("SUPER_ADMIN".equals(user.getRole().getName())) {
//            return true;
//        }
//        List<Permission> permissions = user.getRole().getPermissions();
//        for (Permission perm : permissions) {
//            if (perm.name().equalsIgnoreCase(permission.name())) {
//                return true;
//            }
//        }
//        return false;
    }
}
