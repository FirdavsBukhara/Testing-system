package uz.sinov.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import uz.sinov.entity.Role;
import uz.sinov.enums.Permission;
import uz.sinov.repository.RoleRepository;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class ApplicationRunner {
    private final RoleRepository roleRepository;

    @Bean
    public CommandLineRunner commandLineRunner() {
        return args -> {
            this.addPermissionsToSuperAdminRole();
            this.addPermissionsToUserRole();
        };
    }

    private void addPermissionsToUserRole() {
        Optional<Role> roleOptional = roleRepository.findByName("USER");
        if (roleOptional.isPresent()) {
            Role role = roleOptional.get();
            role.setPermissions(List.of(Permission.START_TEST_SESSION,
                    Permission.FINISH_TEST_SESSION,
                    Permission.DISABLE_MY_SUBSCRIPTION));
            roleRepository.save(role);
            return;
        }
        Role role = Role.childBuilder()
                .name("USER")
                .description("User role")
                .permissions(List.of(Permission.START_TEST_SESSION,
                        Permission.FINISH_TEST_SESSION,
                        Permission.DISABLE_MY_SUBSCRIPTION))
                .build();
        roleRepository.save(role);
    }

    private void addPermissionsToSuperAdminRole() {
        Optional<Role> roleOptional = roleRepository.findByName("SUPER_ADMIN");
        if (roleOptional.isPresent()) {
            Role role = roleOptional.get();
            role.setPermissions(List.of(Permission.values()));
            roleRepository.save(role);
            return;
        }
        Role role = Role.childBuilder()
                .name("SUPER_ADMIN")
                .description("Super Admin")
                .permissions(List.of(Permission.values()))
                .build();
        roleRepository.save(role);
    }
}
