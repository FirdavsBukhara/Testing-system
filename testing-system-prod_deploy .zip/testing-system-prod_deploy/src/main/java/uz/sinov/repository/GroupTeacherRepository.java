package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.GroupTeacher;

import java.util.List;
import java.util.Optional;

public interface GroupTeacherRepository extends JpaRepository<GroupTeacher, String> {
    @Query("select (count(g) > 0) from GroupTeacher g where g.userId = ?1 and g.groupId = ?2")
    boolean existsByUserIdAndGroupId(String userId, String groupId);

    @Query("""
            select g from GroupTeacher g
                where g.groupId = ?1 and
                g.userId = ?2 and
                g.deleted = false and
                g.status = uz.sinov.enums.GroupTeacherStatus.IN""")
    Optional<GroupTeacher> findByGroupIdAndUserId(String groupId, String userId);

    @Query("""
            select g from GroupTeacher g
                where g.groupId = ?1 and
                g.deleted = false and
                g.status = uz.sinov.enums.GroupTeacherStatus.IN""")
    List<GroupTeacher> findByGroupId(String groupId);

    @Query("""
            select (count(g) > 0) from GroupTeacher g 
                where g.userId = ?1 and 
                g.deleted = false and
                g.status = uz.sinov.enums.GroupTeacherStatus.IN""")
    boolean existsByUserId(String userId);
}