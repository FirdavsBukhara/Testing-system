package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.Subject;

import java.util.List;
import java.util.Optional;

public interface SubjectRepository extends JpaRepository<Subject, Integer> {
    @NotNull
    @Override
    @Query("select s from Subject s where s.id = ?1 and s.deleted = false")
    Optional<Subject> findById(@NotNull Integer id);

    @NotNull
    @Override
    @Query("select s from Subject s where s.deleted = false order by s.createdAt desc")
    List<Subject> findAll();
}