package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.QuestionLevel;

import java.util.List;
import java.util.Optional;

public interface QuestionLevelRepository extends JpaRepository<QuestionLevel, Integer> {
    @Query("select q from QuestionLevel q where q.name ilike ?1 and q.level = ?2 and q.deleted = false")
    Optional<QuestionLevel> findByNameAndLevel(String name, Integer level);

    @NotNull
    @Query("select q from QuestionLevel q where q.deleted = false")
    List<QuestionLevel> findAll();

    @NotNull
    @Query("select q from QuestionLevel q where q.deleted = false and q.id = ?1")
    Optional<QuestionLevel> findById(@NotNull Integer id);

    @Query("select q from QuestionLevel q where q.id in ?1 and q.deleted = false")
    List<QuestionLevel> findByIdIn(List<Integer> ids);
}