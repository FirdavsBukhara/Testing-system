package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.StudentTask;

import java.util.List;
import java.util.Optional;

public interface StudentTaskRepository extends JpaRepository<StudentTask, String> {
    @Query("select s from StudentTask s where s.studentId = ?1 and s.task.id = ?2")
    Optional<StudentTask> findByStudentIdAndTaskId(String studentId, String id);

    @Query("select s from StudentTask s where s.studentId = ?1 and s.testSessionId = ?2")
    Optional<StudentTask> findByStudentIdAndTestSessionId(String studentId, String testSessionId);

    @Query("select s from StudentTask s where s.task.id = ?1")
    List<StudentTask> findByTaskId(String id);

    @Query("select s from StudentTask s where s.testSessionId = ?1")
    Optional<StudentTask> findByTestSessionId(String testSessionId);
}