package uz.sinov.repository;

import lombok.NonNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.Document;

import java.util.Optional;

public interface DocumentRepository extends JpaRepository<Document, Integer> {
    @Query("select d from Document d where d.generatedName = ?1")
    Optional<Document> findByGeneratedName(String generatedName);

    @NonNull
    @Override
    @Query("select d from Document d where d.id = ?1")
    Optional<Document> findById(@NonNull Integer id);
}