package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.GroupStudent;

import java.util.List;
import java.util.Optional;

public interface GroupStudentRepository extends JpaRepository<GroupStudent, String> {
    @Query("""
            select (count(g) > 0) from GroupStudent g
                where g.userId = ?1 and
                g.groupId = ?2 and
                g.status = uz.sinov.enums.GroupStudentStatus.IN""")
    boolean existsByUserIdAndGroupId(String userId, String groupId);

    @Query("""
            select g from GroupStudent g
                where g.groupId = ?1 and
                g.userId = ?2 and
                g.status = uz.sinov.enums.GroupStudentStatus.IN""")
    Optional<GroupStudent> findByGroupIdAndUserId(String groupId, String userId);

    @Query("select g from GroupStudent g where g.groupId = ?1 and g.status = uz.sinov.enums.GroupStudentStatus.IN")
    List<GroupStudent> findByGroupId(String groupId);
}