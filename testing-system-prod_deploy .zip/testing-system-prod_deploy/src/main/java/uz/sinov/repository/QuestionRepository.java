package uz.sinov.repository;

import lombok.NonNull;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.Question;
import uz.sinov.entity.testing.QuestionLevel;

import java.util.List;
import java.util.Optional;

public interface QuestionRepository extends JpaRepository<Question, String> {
    @NonNull
    @Override
    @Query("select q from Question q where q.id = ?1 and q.deleted = false")
    Optional<Question> findById(@NonNull String id);

    @Query("select q from Question q where q.deleted = false and (?1 is null or ?1 = q.subject.id)")
    Page<Question> findByPage(Integer subjectId, Pageable pageable);

    @Query("""
            select q from Question q
            where q.subject.id = ?1 and
                  q.questionLevel in ?2
                  order by RANDOM()
                  limit ?3""")
    List<Question> findRandomQuestions(Integer id, List<QuestionLevel> questionLevels, Integer questionCount);
}