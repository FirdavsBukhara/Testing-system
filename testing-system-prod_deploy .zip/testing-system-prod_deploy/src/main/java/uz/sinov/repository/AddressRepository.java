package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.Address;

import java.util.Optional;

public interface AddressRepository extends JpaRepository<Address, Integer> {
    @NotNull
    @Override
    @Query("select a from Address a where a.id = ?1 and a.deleted = false ")
    Optional<Address> findById(@NotNull Integer id);
}