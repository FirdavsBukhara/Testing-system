package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.TestSession;
import uz.sinov.enums.TestSessionStatus;

import java.util.List;
import java.util.Optional;

public interface TestSessionRepository extends JpaRepository<TestSession, String> {
    @Query("select count(t) from TestSession t where t.userId = ?1")
    long countByUserId(String userId);

    @Query("select t from TestSession t where t.userId = ?1 and t.id = ?2")
    Optional<TestSession> findByUserIdAndId(String userId, String id);

    @Query("""
            select t from TestSession t
            where t.userId = ?1 and
            t.status <> uz.sinov.enums.TestSessionStatus.FINISHED
            order by t.startedAt""")
    List<TestSession> findByUserIdAndActive(String userId);

    @Query("""
            select t from TestSession t
            where t.status = uz.sinov.enums.TestSessionStatus.STARTED
            and t.finishedAt < CURRENT_TIMESTAMP""")
    List<TestSession> findUnfinished();
}