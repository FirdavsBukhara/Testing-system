package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.sinov.entity.testing.TestCriteria;

public interface TestSessionCriteriaRepository extends JpaRepository<TestCriteria, Integer> {
}