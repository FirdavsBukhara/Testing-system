package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.UserSMS;
import uz.sinov.enums.SMSCodeType;

public interface UserSMSRepository extends JpaRepository<UserSMS, Integer> {
    @Query("""
            select u
            from UserSMS u
            where u.userId = ?1
                  and u.type = ?2
                  and u.expired is false
                  and  u.toTime > CURRENT_TIMESTAMP
            order by u.id desc
            limit 1""")
    UserSMS findByUserId(String userId, SMSCodeType type);
}