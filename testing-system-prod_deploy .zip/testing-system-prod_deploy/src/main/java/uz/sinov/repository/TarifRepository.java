package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.Tarif;
import uz.sinov.enums.TarifType;

import java.util.List;
import java.util.Optional;

public interface TarifRepository extends JpaRepository<Tarif, String> {
    @NotNull
    @Override
    @Query("select t from Tarif t where t.id = ?1 and t.deleted = false and t.status = uz.sinov.enums.TarifStatus.ACTIVE")
    Optional<Tarif> findById(@NotNull String id);

    @NotNull
    @Query("select t from Tarif t where t.deleted = false and t.status = uz.sinov.enums.TarifStatus.ACTIVE")
    List<Tarif> findAll();

    @Query("""
            select t from Tarif t
                where t.type = ?1 and
                t.deleted = false and
                t.status = uz.sinov.enums.TarifStatus.ACTIVE""")
    List<Tarif> findByType(TarifType tarifType);
}