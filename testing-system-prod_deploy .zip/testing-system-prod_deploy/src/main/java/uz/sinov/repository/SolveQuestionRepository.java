package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.lang.Nullable;
import org.springframework.transaction.annotation.Transactional;
import uz.sinov.entity.testing.SolveQuestion;

import java.util.List;

public interface SolveQuestionRepository extends JpaRepository<SolveQuestion, Integer> {
    @Query("select s from SolveQuestion s where s.subjectId = ?1 and s.testSession.id = ?2 order by s.createdAt")
    List<SolveQuestion> findBySubjectIdAnTestSessionId(Integer subjectId, String testSessionId);

    @Query("select s from SolveQuestion s where s.testSession.id = ?1 order by s.createdAt")
    List<SolveQuestion> findAllByTestSessionId(String id);

    @Transactional
    @Modifying
    @Query("""
            update SolveQuestion s
            set s.userAnswerId = :userAnswerId
            where s.testSession.id = :testSessionId and
            s.id = :solveQuestionId""")
    void updateByIdAndTestSessionId(String testSessionId, String solveQuestionId, String userAnswerId);

    @Query("select count(s) from SolveQuestion s where s.testSession.id = ?1 and s.userAnswerId is null")
    int countUnmarkedByTestSessionId(String testSessionId);
}