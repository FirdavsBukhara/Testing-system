package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.UserSubscription;

import java.util.List;
import java.util.Optional;

public interface UserSubscriptionRepository extends JpaRepository<UserSubscription, String> {
    @Query("""
            select u from UserSubscription u
                where u.userId = ?1 and
                u.status = uz.sinov.enums.UserSubscriptionStatus.ACTIVE and
                u.deleted = false""")
    Optional<UserSubscription> findByUserId(String userId);

    @Query("select u from UserSubscription u where u.userId = ?1 order by u.createdAt desc ")
    List<UserSubscription> findAllByUserId(String userId);

    @Query("select count(u) from UserSubscription u where u.userId = ?1 and u.tarifId = ?2")
    long countByUserIdAndTarifId(String userId, String tarifId);
}