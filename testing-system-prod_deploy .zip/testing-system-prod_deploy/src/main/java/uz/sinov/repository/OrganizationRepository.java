package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.Organization;

import java.util.List;
import java.util.Optional;

public interface OrganizationRepository extends JpaRepository<Organization, String> {
    @Query("select count(o) from Organization o where o.directorId = ?1")
    long countByDirectorId(String directorId);

    @Query("select o from Organization o where o.directorId = ?1")
    List<Organization> findByDirectorId(String directorId);

    @Query("select o from Organization o where o.id = ?1 and o.directorId = ?2")
    Optional<Organization> findByIdAndDirectorId(String organizationId, String directorId);

    @NotNull
    @Override
    @Query("select o from Organization o where o.id = ?1 and o.deleted = false and o.status = uz.sinov.enums.OrganizationStatus.OPEN")
    Optional<Organization> findById(@NotNull String id);

    @Override
    @NotNull
    @Query("select o from Organization o")
    Page<Organization> findAll(@NotNull Pageable pageable);
}