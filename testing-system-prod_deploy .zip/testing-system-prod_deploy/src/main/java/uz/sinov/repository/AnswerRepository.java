package uz.sinov.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.Answer;

import java.util.List;
import java.util.Optional;

public interface AnswerRepository extends JpaRepository<Answer, String> {
    @Query("select a from Answer a where a.questionId = ?1 ")
    List<Answer> findByQuestionId(String questionId);

    @Query("select a from Answer a where a.questionId = ?1 and a.isCorrect = ?2")
    Optional<Answer> findByQuestionIdAndIsCorrect(String questionId, boolean isCorrect);
}