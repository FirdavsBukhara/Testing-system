package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.TarifConstraint;

import java.util.Optional;

public interface TarifConstraintRepository extends JpaRepository<TarifConstraint, String> {
    @Query("select t from TarifConstraint t where t.tarifId = ?1 and t.deleted = false")
    Optional<TarifConstraint> findByTarifId(String tarifId);
}