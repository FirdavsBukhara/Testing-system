package uz.sinov.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.Group;

import java.util.List;

public interface GroupRepository extends JpaRepository<Group, String> {
    @Query("select count(g) from groups g where g.organizationId = ?1 and g.deleted = false")
    short countByOrganizationId(String organizationId);

    @Query("select g from groups g where g.deleted = false")
    List<Group> findAllActive();

    @Query("select g from groups g where g.organizationId = ?1")
    List<Group> findByOrganizationId(String organizationId);
}