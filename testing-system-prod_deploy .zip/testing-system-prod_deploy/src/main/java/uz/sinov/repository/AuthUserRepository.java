package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.AuthUser;

import java.util.Optional;

public interface AuthUserRepository extends JpaRepository<AuthUser, String> {
    @Query("select a from AuthUser a where a.phoneNumber = ?1 and a.status = 'ACTIVE' and a.deleted = false")
    Optional<AuthUser> findActiveByPhoneNumber(String phoneNumber);

    @Query("select a from AuthUser a where a.phoneNumber = ?1 and a.status <> 'DELETED' and a.deleted = false")
    Optional<AuthUser> findByPhoneNumber(String phoneNumber);

    @NotNull
    @Override
    @Query("select a from AuthUser a where a.id = ?1 and a.deleted = false and a.status <> 'DELETED'")
    Optional<AuthUser> findById(@NotNull String id);
}