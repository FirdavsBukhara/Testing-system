package uz.sinov.repository;

import org.jetbrains.annotations.NotNull;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uz.sinov.entity.testing.TestHistory;

import java.util.Optional;

public interface TestHistoryRepository extends JpaRepository<TestHistory, Integer> {
    @Query("select t from TestHistory t where t.testSessionId = ?1")
    Optional<TestHistory> findByTestSessionId(String testSessionId);

    @NotNull
    @Override
    @Query("select t from TestHistory t where t.id = ?1")
    Optional<TestHistory> findById(@NotNull Integer id);

    @Query("select t from TestHistory t where t.userId = ?1 order by t.id desc")
    Page<TestHistory> findByUserId(String userId, Pageable pageable);
}