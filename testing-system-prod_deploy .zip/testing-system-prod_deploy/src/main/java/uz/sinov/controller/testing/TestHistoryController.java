package uz.sinov.controller.testing;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.PagingRequest;
import uz.sinov.payload.response.PageableResponseDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.test_history.TestHistoryResponseDto;
import uz.sinov.service.testing.TestHistoryService;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/test/history")
@Tag(name = "Test History Controller", description = "Test History API")
public class TestHistoryController {
    private final TestHistoryService testHistoryService;

    @Operation(summary = "User o'zi ishlagan test tarixini olish")
    @PostMapping("/all")
    public ResponseDto<PageableResponseDto<TestHistoryResponseDto>> getMyHistory(@RequestBody PagingRequest paging) {
        return new ResponseDto<>(testHistoryService.getMyHistory(paging));
    }
}

