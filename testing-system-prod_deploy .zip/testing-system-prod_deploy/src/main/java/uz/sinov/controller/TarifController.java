package uz.sinov.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.tarif.TarifCreateRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.tarif.TarifResponseDto;
import uz.sinov.service.TarifService;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/tarifs")
@Tag(name = "Tarif Controller", description = "Tarif API")
public class TarifController {
    private final TarifService tarifService;

    @Operation(summary = "For admins, This API is used for create new tarif")
    @PostMapping(value = "")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).CREATE_TARIF)")
    public ResponseDto<String> createTarif(@RequestBody TarifCreateRequestDto request) {
        String response = tarifService.createTarif(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "For all users, This API is used for get tarifs by type")
    @GetMapping("")
    public ResponseDto<List<TarifResponseDto>> getTarifs(@RequestParam(value = "type") String type) {
        List<TarifResponseDto> response = tarifService.getTarifs(type);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "For all users, This API is used for get tarif by id")
    @GetMapping("/{id:.*}")
    public ResponseDto<TarifResponseDto> getById(@PathVariable String id) {
        TarifResponseDto response = tarifService.findTarifResponseById(id);
        return new ResponseDto<>(response);
    }

}

