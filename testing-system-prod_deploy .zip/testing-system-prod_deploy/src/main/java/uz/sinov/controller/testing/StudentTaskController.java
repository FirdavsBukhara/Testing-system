package uz.sinov.controller.testing;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.student_task.StudentTaskResponseDto;
import uz.sinov.service.testing.StudentTaskService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/student-tasks")
@Tag(name = "Student Task Controller", description = "Student Task API")
public class StudentTaskController {

    private final StudentTaskService studentTaskService;

    @Operation(summary = "Task id orqali barcha studentlar tasklarini olish ")
    @GetMapping("")
    public ResponseDto<List<StudentTaskResponseDto>> getAllByTaskId(@RequestParam String taskId) {
        List<StudentTaskResponseDto> response = studentTaskService.getAllByTaskId(taskId);
        return new ResponseDto<>(response);
    }
}

