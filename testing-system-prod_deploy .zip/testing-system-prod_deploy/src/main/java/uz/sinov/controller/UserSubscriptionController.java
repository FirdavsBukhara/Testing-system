package uz.sinov.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.user_subscribe.UserSubscribeRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.user_subscribe.UserSubscriptionResponseDto;
import uz.sinov.service.UserSubscriptionService;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/subscriptions")
@Tag(name = "Subscription Controller", description = "User subscription API")
public class UserSubscriptionController {

    private final UserSubscriptionService userSubscriptionService;

    @Operation(summary = "For all users, This API is used subscribe to tarif means buy tarif")
    @PostMapping(value = "")
    public ResponseDto<String> subscribe(@RequestBody UserSubscribeRequestDto request) {
        String response = userSubscriptionService.subscribe(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "For admin, This API is used disable user subscription by userid")
    @PostMapping("/disable/{userId:.*}")//hasPermission disable subscription
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).DISABLE_USER_SUBSCRIPTION)")
    public ResponseDto<String> disableSubscription(@PathVariable String userId) {
        String response = userSubscriptionService.disableUserSubscription(userId);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha foydalanuvchilar uchun, obunani bekor qilish uchun")
    @PostMapping("/disable")//has permission disable my subscription
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).DISABLE_MY_SUBSCRIPTION)")
    public ResponseDto<String> disableMySubscription() {
        String response = userSubscriptionService.disableMySubscription();
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha foydalanuvchilar uchun, foydalanuvchi o'zi sotib olgan barcha obunalarni ko'rish uchun")
    @GetMapping()//hasPermission get my subscriptions
    public ResponseDto<List<UserSubscriptionResponseDto>> getMySubscriptions() {
        List<UserSubscriptionResponseDto> response = userSubscriptionService.getMySubscriptions();
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Admin uchun, foydalanuvchi id si orqali foydalanuvchi sotib olgan barcha obunalarni ko'rish uchun")
    @GetMapping("/{userId:.*}")//hasPermission get user subscriptions
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).VIEW_USER_SUBSCRIPTION)")
    public ResponseDto<List<UserSubscriptionResponseDto>> getUserSubscriptions(@PathVariable String userId) {
        List<UserSubscriptionResponseDto> response = userSubscriptionService.getUserSubscriptions(userId);
        return new ResponseDto<>(response);
    }
}

