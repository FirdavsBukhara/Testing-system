package uz.sinov.controller.testing;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.solve_question.SolveQuestionListUpdateRequestDto;
import uz.sinov.payload.request.test_session.TestSessionCreateOrUpdateRequestDto;
import uz.sinov.payload.request.test_session.TestSessionIdRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.solve_question.RemainQuestionCountResponseDto;
import uz.sinov.payload.response.test_session.TestCountsResponseDto;
import uz.sinov.payload.response.test_session.TestSessionResponseDto;
import uz.sinov.payload.response.test_session.TestSessionStartResponseDto;
import uz.sinov.service.testing.SolveQuestionService;
import uz.sinov.service.testing.TestSessionService;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/test")
@Tag(name = "Test Controller", description = "Test API")
public class TestController {
    private final TestSessionService testSessionService;
    private final SolveQuestionService solveQuestionService;

    @GetMapping("/session/active")
    @Operation(summary = "User o'zini Aktiv test sessionlarni olish")
    public ResponseDto<List<TestSessionResponseDto>> getAllActiveTestSessions() {
        List<TestSessionResponseDto> response = testSessionService.getAllActiveTestSessions();
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Test session yaratish")
    @PostMapping("/session")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).START_TEST_SESSION)")
    public ResponseDto<TestSessionResponseDto> createTestSession(@Valid @RequestBody TestSessionCreateOrUpdateRequestDto request) {
        TestSessionResponseDto response = testSessionService.createTestSession(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Testni testsession orqali boshlash")
    @PostMapping("/start")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).START_TEST_SESSION)")
    public ResponseDto<TestSessionStartResponseDto> startTestSession(@Valid @RequestBody TestSessionIdRequestDto request) {
        TestSessionStartResponseDto response = testSessionService.startTestSession(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Test session javoblarni sistemaga belgilash")
    @PutMapping("/session/answers")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).FINISH_TEST_SESSION)")
    public ResponseDto<RemainQuestionCountResponseDto> updateTestSession(@Valid @RequestBody SolveQuestionListUpdateRequestDto request) {
        RemainQuestionCountResponseDto response = solveQuestionService.updateSolveQuestion(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Test sessionni yakunlash")
    @PostMapping("/finish")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).FINISH_TEST_SESSION)")
    public ResponseDto<TestCountsResponseDto> finish(@RequestBody TestSessionIdRequestDto request) {
        TestCountsResponseDto response = testSessionService.finish(request);
        return new ResponseDto<>(response);
    }
}

