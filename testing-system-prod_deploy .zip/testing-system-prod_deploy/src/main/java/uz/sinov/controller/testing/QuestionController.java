package uz.sinov.controller.testing;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.question.QuestionCreateRequestDto;
import uz.sinov.payload.request.question.QuestionPageRequestDto;
import uz.sinov.payload.response.PageableResponseDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.question.QuestionResponseDto;
import uz.sinov.service.testing.QuestionService;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/questions")
@Tag(name = "Question Controller", description = "Question API")
public class QuestionController {
    private final QuestionService questionService;

    @Operation(summary = "Adminlar uchun yoki permission bor bo'lgan ustozlar uchun , Yangi savol yaratish ")
    @PostMapping()
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).CREATE_QUESTION)")
    public ResponseDto<String> create(@Valid @RequestBody QuestionCreateRequestDto dto) {
        String response = questionService.create(dto);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Admin yoki ustozlar, Savollar ro'yxatini ko'rish uchun")
    @PostMapping("/page")
    public ResponseDto<PageableResponseDto<QuestionResponseDto>> getByPage(@RequestBody QuestionPageRequestDto request) {
        PageableResponseDto<QuestionResponseDto> response = questionService.findByPage(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Admin yoki ustozlar, Savoll ma'lumotini id si orqali ko'rish uchun")
    @GetMapping("/{id:.*}")
    public ResponseDto<QuestionResponseDto> getById(@PathVariable(name = "id") String id) {
        log.info("Question requested by id {}", id);
        QuestionResponseDto response = questionService.findResponseById(id);
        return new ResponseDto<>(response);
    }
}
