package uz.sinov.controller.testing;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.question_level.QuestionLevelCreateRequestDto;
import uz.sinov.payload.request.question_level.QuestionLevelListRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.question_level.QuestionLevelResponseDto;
import uz.sinov.service.testing.QuestionLevelService;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/question-levels")
@Tag(name = "Question Level Controller", description = "Question Level API")
public class QuestionLevelController {
    private final QuestionLevelService questionLevelService;

    @Operation(summary = "Adminlar uchun , Yangi savol qiyinlik darajasini qo'shish")
    @PostMapping()
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).CREATE_QUESTION_LEVEL)")
    public ResponseDto<String> create(@Valid @RequestBody QuestionLevelCreateRequestDto dto) {
        String response = questionLevelService.create(dto);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha uchun , Savol qiyinlik darajalarini ro'yxatini ko'rish uchun")
    @GetMapping()
    public ResponseDto<List<QuestionLevelResponseDto>> getAll() {
        List<QuestionLevelResponseDto> response = questionLevelService.findAll();
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha uchun , Savol qiyinlik darajalarini idlari orqali ko'rish uchun")
    @PostMapping("/by-ids")
    public ResponseDto<List<QuestionLevelResponseDto>> getAllByIds(@RequestBody QuestionLevelListRequestDto request) {
        List<QuestionLevelResponseDto> response = questionLevelService.findResponseAllByIds(request);
        return new ResponseDto<>(response);
    }
}
