package uz.sinov.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.entity.AuthUser;
import uz.sinov.payload.request.auth.RefreshTokenRequestDto;
import uz.sinov.payload.request.auth.TokenRequestDto;
import uz.sinov.payload.request.auth.UserActivateRequestDto;
import uz.sinov.payload.request.auth_user.AuthUserResponseDTO;
import uz.sinov.payload.request.auth_user.ResendCodeRequestDto;
import uz.sinov.payload.request.auth_user.UserCreateRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.auth.TokenResponseDto;
import uz.sinov.service.AuthUserService;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/auth")
public class AuthController {
    private final AuthUserService authUserService;

    @PostMapping("/user/register")
    public ResponseDto<String> register(@Valid @RequestBody UserCreateRequestDto dto) {
        AuthUser authUser = authUserService.create(dto);
        return new ResponseDto<>("User created");
    }

    @PostMapping("/token/access")
    public ResponseDto<TokenResponseDto> generateToken(@Valid @RequestBody TokenRequestDto request) {
        TokenResponseDto tokenResponse = authUserService.generateToken(request);
        return new ResponseDto<>(tokenResponse);
    }

    @PostMapping("/token/refresh")
    public ResponseDto<TokenResponseDto> refreshToken(@Valid @RequestBody RefreshTokenRequestDto request) {
        TokenResponseDto tokenResponse = authUserService.refreshToken(request);
        return new ResponseDto<>(tokenResponse);
    }

    @PostMapping("/user/activate")
    public ResponseDto<Boolean> activate(@Valid @RequestBody UserActivateRequestDto dto) {
        Boolean activated = authUserService.activate(dto);
        return new ResponseDto<>(activated, "User activated");
    }

    @PostMapping("/code/resend")
    public ResponseDto<Boolean> resendCode(@Valid @RequestBody ResendCodeRequestDto dto) {
        authUserService.resendCode(dto);
        return new ResponseDto<>(true, "Sms code sent successfully");
    }

    @PostMapping("/token/validate")
    public ResponseDto<Boolean> validateToken(@RequestBody String token) {
        return new ResponseDto<>(true);
    }

    @GetMapping("/user/profile")
    public ResponseDto<AuthUserResponseDTO> getProfile() {
        AuthUserResponseDTO response = authUserService.getProfile();
        return new ResponseDto<>(response);
    }
}
