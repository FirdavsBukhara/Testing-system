package uz.sinov.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.Table;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.PagingRequest;
import uz.sinov.payload.request.organization.OrganizationCreateRequestDto;
import uz.sinov.payload.response.PageableResponseDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.organization.OrganizationResponseDto;
import uz.sinov.service.OrganizationService;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/organizations")
@Tag(name = "Organization Controller", description = "Organization API")
public class OrganizationController {
    private final OrganizationService organizationService;

    @Operation(summary = "Obunasi bor foydalanuvchi uchun, yangi tashkilot yaratish uchun")
    @PostMapping(value = "")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).CREATE_ORGANIZATION)")
    public ResponseDto<String> create(@RequestBody OrganizationCreateRequestDto dto) {
        String response = organizationService.createOrganization(dto);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha foydalanuvchilar uchun, foydalanuvchi o'z tashkilotlarini ko'rish uchun")
    @GetMapping(value = "")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).VIEW_ORGANIZATIONS)")
    public ResponseDto<List<OrganizationResponseDto>> getMyOrganizations() {
        List<OrganizationResponseDto> response = organizationService.getMyOrganizations();
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Adminlar uchun, barcha tashkilotlarini ko'rish uchun")
    @PostMapping(value = "/all")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).VIEW_ORGANIZATIONS)")
    public ResponseDto<PageableResponseDto<OrganizationResponseDto>> getAllOrganizations(@RequestBody PagingRequest paging) {
        PageableResponseDto<OrganizationResponseDto> response = organizationService.getAllOrganizations(paging);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha foydalanuvchi uchun uchun, tashkilot id si orqali tashkilot malumotlarini ko'rish uchun")
    @GetMapping(value = "/{id:.*}")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).VIEW_ORGANIZATIONS)")
    public ResponseDto<OrganizationResponseDto> getOneOrganizationById(@PathVariable String id) {
        OrganizationResponseDto response = organizationService.organizationResponseById(id);
        return new ResponseDto<>(response);
    }
}

