package uz.sinov.controller.testing;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.subject.SubjectCreateRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.subject.SubjectResponseDto;
import uz.sinov.service.testing.SubjectService;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/subjects")
@Tag(name = "Subject Controller", description = "Subject API")
public class SubjectController {
    private final SubjectService subjectService;

    @Operation(summary = "Adminlar yoki permission bor ustozlar uchun , Yangi fan yaratish")
    @PostMapping()
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).CREATE_SUBJECT)")
    public ResponseDto<String> create(@Valid @RequestBody SubjectCreateRequestDto dto) {
        String subject = subjectService.create(dto);
        return new ResponseDto<>(subject);
    }

    @Operation(summary = "Barcha uchun , Fanlar ro'yxatini ko'rish uchun")
    @GetMapping()
    public ResponseDto<List<SubjectResponseDto>> getAll() {
        List<SubjectResponseDto> response = subjectService.findAll();
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Barcha uchun , Fan malumotlarini id orqali ko'rish uchun")
    @GetMapping("/{id:.*}")
    public ResponseDto<SubjectResponseDto> getById(@PathVariable(name = "id") Integer id) {
        log.info("Subject requested by id {}", id);
        SubjectResponseDto subject = subjectService.findResponseById(id);
        return new ResponseDto<>(subject);
    }

}
