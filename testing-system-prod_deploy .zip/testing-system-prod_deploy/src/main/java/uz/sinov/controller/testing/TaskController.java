package uz.sinov.controller.testing;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.task.TaskCreateRequestDto;
import uz.sinov.payload.request.task.TaskStartRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.task.TaskResponseDto;
import uz.sinov.payload.response.test_session.TestSessionStartResponseDto;
import uz.sinov.service.testing.TaskService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/tasks")
@Tag(name = "Task Controller", description = "Task API")
public class TaskController {
    private final TaskService taskService;

    @Operation(summary = "Ustozlar uchun , Task yaratish")
    @PostMapping("/add")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).CREATE_TASK)")
    public ResponseDto<String> create(@RequestBody TaskCreateRequestDto request) {
        String response = taskService.create(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Studentlar uchun , Taskni boshlash")
    @PostMapping("/start")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).START_TASK)")
    public ResponseDto<TestSessionStartResponseDto> startTask(@RequestBody TaskStartRequestDto request) {
        TestSessionStartResponseDto response = taskService.start(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Guruhdagi barcha tasklarni olish")
    @GetMapping("/all")
    public ResponseDto<List<TaskResponseDto>> getGroupTasks(@RequestParam String groupId) {
        List<TaskResponseDto> response = taskService.getGroupTasks(groupId);
        return new ResponseDto<>(response);
    }
}

