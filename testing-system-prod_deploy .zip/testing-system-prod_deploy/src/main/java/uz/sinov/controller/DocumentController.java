package uz.sinov.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import uz.sinov.entity.Document;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.service.DocumentService;

import java.io.IOException;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/files")
@Tag(name = "Document Controller", description = "Document API")
public class DocumentController {
    private final DocumentService documentService;

    @Operation(summary = "Barcha foydalanuvchilar file yuborish uchun")
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseDto<Document> upload(@RequestBody MultipartFile file) throws IOException {
        Document document = documentService.saveMultipartDocument(file);
        return new ResponseDto<>(document);
    }

    @Operation(summary = "File nomi orqali fileni yuklab olish uchun, agar file mavjud bo'lsa")
    @GetMapping(value = "/{name:.*}", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<InputStreamResource> downloadByGeneratedName(@PathVariable String name) {
        return documentService.downloadByGeneratedName(name);
    }

    @Operation(summary = "File nomi orqali file malumotlarini olish uchun, agar file mavjud bo'lsa")
    @GetMapping("/data/{name:.*}")
    public ResponseDto<Document> documentByGeneratedName(@PathVariable String name) {
        Document document = documentService.findByGeneratedName(name);
        return new ResponseDto<>(document);
    }
}

