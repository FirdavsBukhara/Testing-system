package uz.sinov.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.group.GroupStudentAddRequestDto;
import uz.sinov.payload.request.group.GroupStudentRemoveRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.group.GroupStudentResponseDto;
import uz.sinov.service.GroupStudentService;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/group-students")
@Tag(name = "Group Student Controller", description = "Group Student API")
public class GroupStudentController {
    private final GroupStudentService groupStudentService;

    @Operation(summary = "Obunasi bor bo'lgan tashkilot rahbari yoki guruh o'qituvchisi , guruhga talaba qo'shish uchun")
    @PostMapping("/add")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).ADD_STUDENT_TO_GROUP)")
    public ResponseDto<String> addStudentToGroup(@RequestBody GroupStudentAddRequestDto request) {
        String response = groupStudentService.addStudentToGroup(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Obunasi bor bo'lgan tashkilot rahbari yoki guruh o'qituvchisi , guruhga talabani guruhdan o'chirish uchun uchun")
    @PostMapping("/remove")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).REMOVE_STUDENT_FROM_GROUP)")
    public ResponseDto<String> removeStudentFromGroup(@RequestBody GroupStudentRemoveRequestDto request) {
        String response = groupStudentService.removeFromGroup(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Guruh id si orqali guruh talabalari ro'yxatini ko'rish uchun")
    @GetMapping("/{groupId:.*}")
    public ResponseDto<List<GroupStudentResponseDto>> getAllGroupStudents(@PathVariable String groupId) {
        return new ResponseDto<>(groupStudentService.getAllGroupStudents(groupId));
    }
}

