package uz.sinov.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.sinov.payload.request.group.GroupTeacherAddRequestDto;
import uz.sinov.payload.request.group.GroupTeacherRemoveRequestDto;
import uz.sinov.payload.response.ResponseDto;
import uz.sinov.payload.response.group.GroupTeacherResponseDto;
import uz.sinov.service.GroupTeacherService;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/group-teachers")
@Tag(name = "Group Teacher Controller", description = "Group Teacher API")
public class GroupTeacherController {
    private final GroupTeacherService groupTeacherService;

    @Operation(summary = "Obunasi bor bo'lgan tashkilot rahbari , tashkilotga o'qituvchi qo'shish uchun")
    @PostMapping("/add")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).ADD_TEACHER_TO_GROUP)")
    public ResponseDto<String> addTeacherToGroup(@RequestBody GroupTeacherAddRequestDto request) {
        String response = groupTeacherService.addTeacherToGroup(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Obunasi bor bo'lgan tashkilot rahbari , tashkilotdan o'qituvchi o'chirishi uchun")
    @PostMapping("/remove")
    @PreAuthorize("@HasPermission.hasPermission(T(uz.sinov.enums.Permission).REMOVE_TEACHER_FROM_GROUP)")
    public ResponseDto<String> removeTeacherFromGroup(@RequestBody GroupTeacherRemoveRequestDto request) {
        String response = groupTeacherService.removeFromGroup(request);
        return new ResponseDto<>(response);
    }

    @Operation(summary = "Guruh id si orqali guruh ustozlarini ko'rish uchun")
    @GetMapping("/{groupId:.*}")
    public ResponseDto<List<GroupTeacherResponseDto>> getAllGroupTeachers(@PathVariable String groupId) {
        return new ResponseDto<>(groupTeacherService.getAllGroupTeachers(groupId));
    }
}

