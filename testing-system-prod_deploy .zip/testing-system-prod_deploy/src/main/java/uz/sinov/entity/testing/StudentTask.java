package uz.sinov.entity.testing;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.entity.Auditable;
import uz.sinov.enums.StudentTaskStatus;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentTask extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String groupId;

    private String studentId;

    private String testSessionId;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Task task;

    private StudentTaskStatus status;

    @Builder(builderMethodName = "childBuilder")
    public StudentTask(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                       String id, String groupId, String studentId, String testSessionId, Task task, StudentTaskStatus status) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.groupId = groupId;
        this.studentId = studentId;
        this.testSessionId = testSessionId;
        this.task = task;
        this.status = status;
    }
}
