package uz.sinov.entity.testing;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TestHistory implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String userId;

    @Column(nullable = false)
    private String testSessionId;

    @Column(nullable = false, updatable = false)
    private LocalDateTime startedAt;

    @Column(nullable = false)
    private LocalDateTime finishedAt;

    private float totalScore;

    private String documentId;

    @Column(columnDefinition = "int default 0")
    private Integer totalQuestionCount;

    @Column(columnDefinition = "int default 0")
    private Integer correctAnswerCount;

    @Column(columnDefinition = "int default 0")
    private Integer wrongAnswerCount;

    @Column(columnDefinition = "int default 0")
    private Integer emptyAnswerCount;
}
