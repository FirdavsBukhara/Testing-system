package uz.sinov.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.UserStatus;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AuthUser extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String name;

    private String phoneNumber;

    @JsonIgnore
    private String password;

    private String profileImg;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Role role;

    @Enumerated(EnumType.STRING)
    private UserStatus status;

    private Double balance;

    @Builder(builderMethodName = "childBuilder")
    public AuthUser(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                    String id, String name, String phoneNumber, String password, String profileImg, Role role,
                    UserStatus status, Double balance) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.profileImg = profileImg;
        this.role = role;
        this.status = Objects.requireNonNullElse(status, UserStatus.NO_ACTIVE);
        this.balance = Objects.requireNonNullElse(balance, 10000.0);
    }
}
