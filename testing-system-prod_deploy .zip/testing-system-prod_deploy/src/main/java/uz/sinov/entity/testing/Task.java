package uz.sinov.entity.testing;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import uz.sinov.entity.Auditable;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Task extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String groupId;

    @Column(length = 100, nullable = false)
    private String name;

    @Column(length = 200, nullable = false)
    private String description;

    private LocalDateTime deadline;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    private TestCriteria criteria;

    @Builder(builderMethodName = "childBuilder")
    public Task(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                String id, String groupId, String name, String description, LocalDateTime deadline, TestCriteria criteria) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.groupId = groupId;
        this.name = name;
        this.description = description;
        this.deadline = deadline;
        this.criteria = criteria;
    }
}
