package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.UserSubscriptionStatus;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class UserSubscription extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String userId;

    private String tarifId;

    private LocalDate fromTime;

    private LocalDate toTime;

    @Enumerated(EnumType.STRING)
    private UserSubscriptionStatus status;

    @Builder(builderMethodName = "childBuilder")
    public UserSubscription(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                            String id, String userId, String tarifId, LocalDate fromTime, LocalDate toTime,
                            UserSubscriptionStatus status) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.userId = userId;
        this.tarifId = tarifId;
        this.fromTime = fromTime;
        this.toTime = toTime;
        this.status = Objects.requireNonNullElse(status, UserSubscriptionStatus.ACTIVE);
    }
}
