package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.GroupSpecialization;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Entity(name = "groups")
@NoArgsConstructor
@AllArgsConstructor
public class Group extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String organizationId;

    private String name;

    private String description;

    @Enumerated(EnumType.STRING)
    private GroupSpecialization specialization;

    @Builder(builderMethodName = "childBuilder")
    public Group(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                 String id, String organizationId, String name, String description, GroupSpecialization specialization) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.organizationId = organizationId;
        this.name = name;
        this.description = description;
        this.specialization = Objects.requireNonNullElse(specialization, GroupSpecialization.GENERAL);
    }
}
