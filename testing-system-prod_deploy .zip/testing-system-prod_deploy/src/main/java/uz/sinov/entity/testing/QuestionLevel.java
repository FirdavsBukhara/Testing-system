package uz.sinov.entity.testing;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.entity.Auditable;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class QuestionLevel extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private String description;

    private Integer level;

    private Float score;

    private Integer timeInSeconds;

    private String textColor;

    @Builder(builderMethodName = "childBuilder")
    public QuestionLevel(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                         Integer id, String name, String description, Integer level, Float score, Integer timeInSeconds, String textColor) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.name = name;
        this.description = description;
        this.level = level;
        this.score = score;
        this.timeInSeconds = timeInSeconds;
        this.textColor = textColor;
    }
}
