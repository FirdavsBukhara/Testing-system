package uz.sinov.entity.testing;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.entity.Auditable;
import uz.sinov.enums.SubjectType;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Subject extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 100, nullable = false)
    private String name;

    @Column(length = 200, nullable = false)
    private String description;

    @Enumerated(EnumType.STRING)
    private SubjectType type;

    @Builder(builderMethodName = "childBuilder")
    public Subject(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                   Integer id, String name, String description, SubjectType type) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.name = name;
        this.description = description;
        this.type = Objects.requireNonNullElse(type, SubjectType.PRIVATE);
    }
}
