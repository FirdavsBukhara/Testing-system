package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.GroupTeacherSpecialization;
import uz.sinov.enums.GroupTeacherStatus;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class GroupTeacher extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String groupId;

    private String userId;

    @Enumerated(EnumType.STRING)
    private GroupTeacherStatus status;

    @Enumerated(EnumType.STRING)
    private GroupTeacherSpecialization teacherSpecialization;

    @Builder(builderMethodName = "childBuilder")
    public GroupTeacher(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                        String id, String groupId, String userId, GroupTeacherStatus status, GroupTeacherSpecialization teacherSpecialization) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.groupId = groupId;
        this.userId = userId;
        this.status = Objects.requireNonNullElse(status, GroupTeacherStatus.IN);
        this.teacherSpecialization = Objects.requireNonNullElse(teacherSpecialization, GroupTeacherSpecialization.GENERAL);
    }
}
