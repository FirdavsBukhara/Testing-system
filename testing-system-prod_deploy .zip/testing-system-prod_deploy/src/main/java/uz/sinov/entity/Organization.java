package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.OrganizationStatus;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Organization extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String directorId;

    private String name;

    private Integer addressId;

    private String description;

    @Enumerated(EnumType.STRING)
    private OrganizationStatus status;

    @Builder(builderMethodName = "childBuilder")
    public Organization(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                        String id, String directorId, String name, Integer addressId, String description, OrganizationStatus status) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.directorId = directorId;
        this.name = name;
        this.addressId = addressId;
        this.description = description;
        this.status = Objects.requireNonNullElse(status, OrganizationStatus.OPEN);
    }
}
