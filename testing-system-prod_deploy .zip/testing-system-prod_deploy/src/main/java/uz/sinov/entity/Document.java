package uz.sinov.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Document extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String uuid = UUID.randomUUID().toString();

    @Column(nullable = false)
    private String originalName;

    @Column(nullable = false, unique = true)
    private String generatedName;

    @Column(nullable = false)
    private String contentType;

    @Column(nullable = false)
    private long size;

    private String filePath;

    @Column(nullable = false)
    private String extension;

    @Builder(builderMethodName = "childBuilder")
    public Document(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                    Integer id, String uuid, String originalName, String generatedName, String contentType, long size,
                    String filePath, String extension) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.uuid = uuid;
        this.originalName = originalName;
        this.generatedName = generatedName;
        this.contentType = contentType;
        this.size = size;
        this.filePath = filePath;
        this.extension = extension;
    }
}
