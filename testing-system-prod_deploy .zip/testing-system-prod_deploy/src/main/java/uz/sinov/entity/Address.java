package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Address extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String region;

    private String district;

    private String street;

    private String home;

    private String lon;

    private String lat;

    @Builder(builderMethodName = "childBuilder")
    public Address(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                   Integer id, String region, String district, String street, String home, String lon, String lat) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.region = region;
        this.district = district;
        this.street = street;
        this.home = home;
        this.lon = lon;
        this.lat = lat;
    }
}
