package uz.sinov.entity.testing;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.entity.Auditable;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Question extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private Subject subject;

    private String imgId;

    @Column(nullable = false, length = 1000)
    private String text;

    @ManyToOne(optional = false, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private QuestionLevel questionLevel;

    @Builder(builderMethodName = "childBuilder")
    public Question(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                    String id, Subject subject, String imgId, String text, QuestionLevel questionLevel) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.subject = subject;
        this.imgId = imgId;
        this.text = text;
        this.questionLevel = questionLevel;
    }
}
