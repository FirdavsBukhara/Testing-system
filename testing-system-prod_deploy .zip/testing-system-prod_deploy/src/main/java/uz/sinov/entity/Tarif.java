package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.TarifStatus;
import uz.sinov.enums.TarifType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Tarif extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String name;

    private Double price;

    private LocalDate fromTime;

    private LocalDate toTime;

    @Enumerated(EnumType.STRING)
    private TarifStatus status;

    private String description;

    @Enumerated(EnumType.STRING)
    private TarifType type = TarifType.FREE;

    @Builder(builderMethodName = "childBuilder")
    public Tarif(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                 String id, String name, Double price, LocalDate fromTime, LocalDate toTime, TarifStatus status,
                 String description, TarifType type) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.name = name;
        this.price = price;
        this.fromTime = fromTime;
        this.toTime = toTime;
        this.description = description;
        this.status = Objects.requireNonNullElse(status, TarifStatus.ACTIVE);
        this.type = Objects.requireNonNullElse(type, TarifType.FREE);
    }
}
