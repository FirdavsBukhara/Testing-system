package uz.sinov.entity;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.Permission;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Role extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String name;

    private String description;

    @Enumerated(EnumType.STRING)
    @ElementCollection(fetch = FetchType.EAGER, targetClass = Permission.class)
    private List<Permission> permissions;

    @Builder(builderMethodName = "childBuilder")
    public Role(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                String id, String name, String description, List<Permission> permissions) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.name = name;
        this.description = description;
        this.permissions = permissions;
    }
}
