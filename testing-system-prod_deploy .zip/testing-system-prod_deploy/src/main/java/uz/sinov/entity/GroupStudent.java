package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.GroupStudentStatus;

import java.time.LocalDateTime;
import java.util.Objects;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class GroupStudent extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String groupId;

    private String userId;

    @Enumerated(EnumType.STRING)
    private GroupStudentStatus status;

    @Builder(builderMethodName = "childBuilder")
    public GroupStudent(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                        String id, String groupId, String userId, GroupStudentStatus status) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.groupId = groupId;
        this.userId = userId;
        this.status = Objects.requireNonNullElse(status, GroupStudentStatus.IN);
    }
}
