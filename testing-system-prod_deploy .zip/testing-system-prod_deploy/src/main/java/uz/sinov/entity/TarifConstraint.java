package uz.sinov.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class TarifConstraint extends Auditable {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String tarifId;

    private Integer periodInDays;

    private Short maxGroupCount;

    private Short maxOrganizationCount;

    private Short maxTestCount;

    private Short maxBuyCount;

    @Builder(builderMethodName = "childBuilder")
    public TarifConstraint(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                           String id, String tarifId, Integer periodInDays, Short maxGroupCount, Short maxOrganizationCount,
                           Short maxTestCount, Short maxBuyCount) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.tarifId = tarifId;
        this.periodInDays = periodInDays;
        this.maxGroupCount = maxGroupCount;
        this.maxOrganizationCount = maxOrganizationCount;
        this.maxTestCount = maxTestCount;
        this.maxBuyCount = maxBuyCount;
    }
}
