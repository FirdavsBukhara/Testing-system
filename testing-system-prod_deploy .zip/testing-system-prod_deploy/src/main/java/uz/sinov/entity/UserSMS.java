package uz.sinov.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import uz.sinov.enums.SMSCodeType;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserSMS extends Auditable implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, updatable = false)
    private String code;

    @Column(nullable = false, updatable = false)
    private String userId;

    @Enumerated(EnumType.STRING)
    private SMSCodeType type;

    @Column(updatable = false)
    private LocalDateTime fromTime;

    private LocalDateTime toTime = LocalDateTime.now().plusMinutes(2);

    private boolean expired;

    @Builder(builderMethodName = "childBuilder")
    public UserSMS(String createdBy, String updatedBy, LocalDateTime createdAt, LocalDateTime updatedAt, boolean deleted,
                   Integer id, String code, String userId, SMSCodeType type, LocalDateTime fromTime, LocalDateTime toTime, boolean expired) {
        super(createdBy, updatedBy, createdAt, updatedAt, deleted);
        this.id = id;
        this.code = code;
        this.userId = userId;
        this.type = type;
        this.fromTime = Objects.requireNonNullElse(fromTime, LocalDateTime.now());
        this.toTime = Objects.requireNonNullElse(toTime, LocalDateTime.now().plusMinutes(2));
        this.expired = expired;
    }
}
